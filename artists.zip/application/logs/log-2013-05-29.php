<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-29 07:41:00 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-29 16:09:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-29 16:09:38 --> 404 Page Not Found --> favicon.ico
