<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-05 00:01:13 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-05 00:02:37 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-05 00:02:37 --> 404 Page Not Found --> js
ERROR - 2013-05-05 00:05:51 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-05 00:05:51 --> 404 Page Not Found --> js
ERROR - 2013-05-05 00:06:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 00:06:20 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-05 00:06:20 --> 404 Page Not Found --> js
ERROR - 2013-05-05 00:06:29 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-05 00:06:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 00:06:30 --> 404 Page Not Found --> js
ERROR - 2013-05-05 00:11:26 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 182
ERROR - 2013-05-05 00:11:27 --> 404 Page Not Found --> js
ERROR - 2013-05-05 00:14:26 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 185
ERROR - 2013-05-05 00:14:26 --> 404 Page Not Found --> js
ERROR - 2013-05-05 00:19:32 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 185
ERROR - 2013-05-05 00:19:33 --> 404 Page Not Found --> js
ERROR - 2013-05-05 00:19:56 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 00:19:56 --> 404 Page Not Found --> js
ERROR - 2013-05-05 00:21:19 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 00:21:20 --> 404 Page Not Found --> js
ERROR - 2013-05-05 00:22:43 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 00:22:44 --> 404 Page Not Found --> js
ERROR - 2013-05-05 00:26:07 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 00:26:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 00:26:07 --> 404 Page Not Found --> js
ERROR - 2013-05-05 00:26:14 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 00:26:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 00:26:14 --> 404 Page Not Found --> js
ERROR - 2013-05-05 00:27:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 00:27:51 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 00:27:51 --> 404 Page Not Found --> js
ERROR - 2013-05-05 00:28:29 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 00:28:30 --> 404 Page Not Found --> js
ERROR - 2013-05-05 00:57:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 00:57:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 00:57:18 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 00:57:28 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 00:57:38 --> Severity: Warning  --> Missing argument 1 for process::skip_process() /home2/adthrif1/public_html/artists/application/controllers/process.php 176
ERROR - 2013-05-05 00:57:38 --> Severity: Notice  --> Undefined variable: id /home2/adthrif1/public_html/artists/application/controllers/process.php 180
ERROR - 2013-05-05 00:57:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2013-05-05 00:57:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 00:57:45 --> Severity: Notice  --> Undefined variable: update_artist /home2/adthrif1/public_html/artists/application/controllers/process.php 206
ERROR - 2013-05-05 00:57:45 --> Severity: Notice  --> Undefined variable: user /home2/adthrif1/public_html/artists/application/controllers/process.php 206
ERROR - 2013-05-05 00:57:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 00:58:43 --> Query error: Unknown column 'artist_id' in 'where clause'
ERROR - 2013-05-05 00:58:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:05:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:05:16 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 01:05:21 --> 404 Page Not Found --> skip_process
ERROR - 2013-05-05 01:05:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:06:37 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 01:06:39 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 01:06:42 --> Query error: Unknown column 'artist_id' in 'where clause'
ERROR - 2013-05-05 01:06:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:08:17 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 01:08:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:23:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:26:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:28:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:28:02 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 01:28:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:28:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:28:06 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 01:28:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:28:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:28:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:28:08 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 01:28:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:28:14 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 01:28:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:28:19 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 01:28:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:28:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:29:04 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 01:29:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:29:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:29:26 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 01:29:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:29:54 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 01:31:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:31:58 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 01:32:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:44:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:44:49 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 01:45:39 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 01:47:41 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 01:48:40 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 01:50:30 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 01:50:36 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 01:50:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:54:06 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 01:55:17 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 01:55:17 --> 404 Page Not Found --> js
ERROR - 2013-05-05 01:57:38 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 01:57:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 01:57:38 --> 404 Page Not Found --> js
ERROR - 2013-05-05 02:08:01 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 02:08:01 --> 404 Page Not Found --> js
ERROR - 2013-05-05 02:09:50 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 02:09:50 --> 404 Page Not Found --> js
ERROR - 2013-05-05 02:27:10 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 02:27:10 --> 404 Page Not Found --> js
ERROR - 2013-05-05 02:28:01 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 02:28:01 --> 404 Page Not Found --> js
ERROR - 2013-05-05 03:13:54 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 03:13:55 --> 404 Page Not Found --> js
ERROR - 2013-05-05 03:13:58 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 03:13:58 --> 404 Page Not Found --> js
ERROR - 2013-05-05 03:14:00 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 03:14:00 --> 404 Page Not Found --> process/js
ERROR - 2013-05-05 03:14:02 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 03:14:03 --> 404 Page Not Found --> process/js
ERROR - 2013-05-05 03:14:23 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 03:14:23 --> 404 Page Not Found --> process/js
ERROR - 2013-05-05 03:14:27 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 03:14:27 --> 404 Page Not Found --> js
ERROR - 2013-05-05 03:14:32 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 03:14:32 --> 404 Page Not Found --> js
ERROR - 2013-05-05 03:31:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 03:31:33 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 03:31:33 --> 404 Page Not Found --> js
ERROR - 2013-05-05 09:49:41 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-05 10:46:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 10:46:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 10:46:13 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 10:46:14 --> 404 Page Not Found --> js
ERROR - 2013-05-05 10:47:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 10:47:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 10:47:13 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 10:47:13 --> 404 Page Not Found --> js
ERROR - 2013-05-05 10:47:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 14:07:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 14:07:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 14:07:49 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 14:07:49 --> 404 Page Not Found --> js
ERROR - 2013-05-05 14:17:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 14:29:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 14:33:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 14:33:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 14:33:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 14:33:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 14:38:28 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 14:38:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 14:38:29 --> 404 Page Not Found --> js
ERROR - 2013-05-05 14:38:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 14:38:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 14:38:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 14:38:48 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 14:38:49 --> 404 Page Not Found --> js
ERROR - 2013-05-05 14:41:15 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 14:41:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 14:41:15 --> 404 Page Not Found --> js
ERROR - 2013-05-05 14:41:21 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 14:41:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 14:41:22 --> 404 Page Not Found --> js
ERROR - 2013-05-05 15:21:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 15:21:01 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 15:21:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 15:21:02 --> 404 Page Not Found --> js
ERROR - 2013-05-05 15:21:14 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 15:21:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 15:21:14 --> 404 Page Not Found --> js
ERROR - 2013-05-05 15:21:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 15:36:58 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-05 15:47:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 15:48:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 16:18:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 16:18:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 16:18:10 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 16:18:10 --> 404 Page Not Found --> js
ERROR - 2013-05-05 16:18:14 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 16:18:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 16:18:14 --> 404 Page Not Found --> js
ERROR - 2013-05-05 16:18:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 16:22:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 17:05:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 17:06:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 17:06:35 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 17:06:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 17:06:36 --> 404 Page Not Found --> js
ERROR - 2013-05-05 17:06:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 17:06:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 17:06:48 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 17:06:49 --> 404 Page Not Found --> js
ERROR - 2013-05-05 17:07:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 17:07:10 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 17:07:10 --> 404 Page Not Found --> js
ERROR - 2013-05-05 17:08:40 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 17:08:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 17:08:40 --> 404 Page Not Found --> js
ERROR - 2013-05-05 17:12:25 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 17:12:26 --> 404 Page Not Found --> js
ERROR - 2013-05-05 17:14:01 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 17:14:01 --> 404 Page Not Found --> js
ERROR - 2013-05-05 17:17:47 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 17:17:48 --> 404 Page Not Found --> js
ERROR - 2013-05-05 17:18:11 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 17:18:11 --> 404 Page Not Found --> js
ERROR - 2013-05-05 17:18:14 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 17:18:14 --> 404 Page Not Found --> js
ERROR - 2013-05-05 17:18:55 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 17:18:56 --> 404 Page Not Found --> js
ERROR - 2013-05-05 17:19:46 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 17:19:46 --> 404 Page Not Found --> js
ERROR - 2013-05-05 17:20:35 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 17:20:35 --> 404 Page Not Found --> js
ERROR - 2013-05-05 17:22:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 17:23:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 17:23:17 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 17:23:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 17:23:17 --> 404 Page Not Found --> js
ERROR - 2013-05-05 17:26:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 17:26:20 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 17:26:20 --> 404 Page Not Found --> js
ERROR - 2013-05-05 17:42:56 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 17:42:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 17:42:56 --> 404 Page Not Found --> js
ERROR - 2013-05-05 17:46:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 17:46:55 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 17:46:55 --> 404 Page Not Found --> js
ERROR - 2013-05-05 17:48:53 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 17:48:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 17:48:54 --> 404 Page Not Found --> js
ERROR - 2013-05-05 17:49:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 17:49:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 17:49:44 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 17:49:45 --> 404 Page Not Found --> js
ERROR - 2013-05-05 17:50:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 17:52:48 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 17:52:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 17:52:48 --> 404 Page Not Found --> js
ERROR - 2013-05-05 17:54:10 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 17:54:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 17:54:10 --> 404 Page Not Found --> js
ERROR - 2013-05-05 18:25:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 18:25:41 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 18:25:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 18:25:41 --> 404 Page Not Found --> js
ERROR - 2013-05-05 18:26:37 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 18:26:37 --> 404 Page Not Found --> js
ERROR - 2013-05-05 18:26:38 --> 404 Page Not Found --> images
ERROR - 2013-05-05 18:27:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 18:28:05 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 18:28:06 --> 404 Page Not Found --> js
ERROR - 2013-05-05 18:31:05 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 194
ERROR - 2013-05-05 18:31:06 --> 404 Page Not Found --> js
ERROR - 2013-05-05 18:32:04 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 194
ERROR - 2013-05-05 18:32:04 --> 404 Page Not Found --> js
ERROR - 2013-05-05 18:33:16 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 194
ERROR - 2013-05-05 18:33:16 --> 404 Page Not Found --> js
ERROR - 2013-05-05 18:35:19 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 194
ERROR - 2013-05-05 18:35:20 --> 404 Page Not Found --> js
ERROR - 2013-05-05 18:36:19 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 194
ERROR - 2013-05-05 18:36:20 --> 404 Page Not Found --> js
ERROR - 2013-05-05 18:38:15 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 194
ERROR - 2013-05-05 18:38:16 --> 404 Page Not Found --> js
ERROR - 2013-05-05 18:48:41 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 194
ERROR - 2013-05-05 18:48:42 --> 404 Page Not Found --> js
ERROR - 2013-05-05 18:48:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 18:50:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 18:50:44 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 194
ERROR - 2013-05-05 18:50:45 --> 404 Page Not Found --> js
ERROR - 2013-05-05 18:56:53 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 194
ERROR - 2013-05-05 18:56:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 18:56:53 --> 404 Page Not Found --> js
ERROR - 2013-05-05 18:59:16 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 194
ERROR - 2013-05-05 18:59:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 18:59:16 --> 404 Page Not Found --> js
ERROR - 2013-05-05 19:00:55 --> 404 Page Not Found --> images
ERROR - 2013-05-05 19:01:32 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 19:01:33 --> 404 Page Not Found --> js
ERROR - 2013-05-05 19:01:33 --> 404 Page Not Found --> images
ERROR - 2013-05-05 19:03:12 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 19:03:12 --> 404 Page Not Found --> js
ERROR - 2013-05-05 19:03:49 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 19:03:49 --> 404 Page Not Found --> js
ERROR - 2013-05-05 19:09:31 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 19:09:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 19:09:31 --> 404 Page Not Found --> js
ERROR - 2013-05-05 19:10:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 20:17:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 20:17:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 20:17:34 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 20:17:35 --> 404 Page Not Found --> js
ERROR - 2013-05-05 20:18:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 21:28:19 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-05 21:29:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 21:29:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-05 21:29:30 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-05 21:29:31 --> 404 Page Not Found --> js
ERROR - 2013-05-05 21:30:47 --> 404 Page Not Found --> favicon.ico
