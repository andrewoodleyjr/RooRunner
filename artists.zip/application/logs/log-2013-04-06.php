<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-04-06 09:11:07 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-06 11:46:11 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-06 17:19:04 --> 404 Page Not Found --> robots.txt
