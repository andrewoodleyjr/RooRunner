<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-04-18 21:55:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-18 22:19:24 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-04-18 22:44:49 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-04-18 22:50:03 --> Severity: Notice  --> Undefined property: stdClass::$id /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 254
ERROR - 2013-04-18 22:50:03 --> Severity: Notice  --> Undefined property: stdClass::$id /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 256
ERROR - 2013-04-18 22:50:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2013-04-18 22:50:27 --> Severity: Warning  --> unlink(/home2/adthrif1/public_html/connect_showcase/files/apps/): Is a directory /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 231
ERROR - 2013-04-18 23:00:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-18 23:01:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-18 23:02:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-18 23:09:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-18 23:11:01 --> The file you are attempting to upload is larger than the permitted size.
ERROR - 2013-04-18 23:11:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-18 23:13:40 --> The file you are attempting to upload is larger than the permitted size.
ERROR - 2013-04-18 23:13:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-18 23:15:31 --> Severity: Warning  --> unlink(/home2/adthrif1/public_html/connect_showcase/files/apps/): Is a directory /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 231
ERROR - 2013-04-18 23:19:53 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-04-18 23:25:54 --> 404 Page Not Found --> files
ERROR - 2013-04-18 23:25:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-18 23:26:02 --> 404 Page Not Found --> files
ERROR - 2013-04-18 23:26:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-18 23:32:42 --> The file you are attempting to upload is larger than the permitted size.
ERROR - 2013-04-18 23:32:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-18 23:33:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-18 23:33:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-18 23:34:03 --> The file you are attempting to upload is larger than the permitted size.
ERROR - 2013-04-18 23:34:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-18 23:35:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-18 23:36:33 --> The file you are attempting to upload is larger than the permitted size.
ERROR - 2013-04-18 23:36:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-18 23:37:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-18 23:37:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-18 23:37:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-18 23:39:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-18 23:44:06 --> 404 Page Not Found --> favicon.ico
