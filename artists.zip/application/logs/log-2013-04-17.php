<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-04-17 10:22:38 --> 404 Page Not Found --> favicon.ico
