<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-04-20 00:12:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-20 00:14:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-20 03:30:05 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-20 09:09:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-20 09:09:30 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2013-04-20 09:09:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-20 09:09:31 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2013-04-20 09:09:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-20 09:09:35 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2013-04-20 12:43:44 --> 404 Page Not Found --> robots.txt
