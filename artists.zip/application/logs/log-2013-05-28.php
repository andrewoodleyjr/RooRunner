<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-28 02:56:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-28 02:56:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-28 04:09:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-28 15:11:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-28 15:11:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-28 16:20:49 --> 404 Page Not Found --> robots.txt
