<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-19 02:24:32 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-19 03:27:17 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-19 09:01:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-19 09:01:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-19 14:54:24 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-19 22:45:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-19 22:45:25 --> 404 Page Not Found --> favicon.ico
