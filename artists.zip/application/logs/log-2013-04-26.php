<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-04-26 03:46:58 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-26 09:43:14 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-26 15:58:49 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-26 17:05:23 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-26 18:07:50 --> 404 Page Not Found --> favicon.ico
