<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-03 01:06:10 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-03 07:53:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-03 08:21:32 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-03 09:38:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-03 09:39:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-03 10:39:01 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-03 13:41:33 --> Severity: 4096  --> Object of class CI_DB_mysql_result could not be converted to string /home2/adthrif1/public_html/artists/application/models/model_users.php 111
ERROR - 2013-05-03 13:41:33 --> Severity: Notice  --> Object of class CI_DB_mysql_result to string conversion /home2/adthrif1/public_html/artists/application/models/model_users.php 111
ERROR - 2013-05-03 13:41:33 --> Severity: Notice  --> Undefined variable: Object /home2/adthrif1/public_html/artists/application/models/model_users.php 111
ERROR - 2013-05-03 13:41:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-03 14:53:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-03 15:44:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-03 15:44:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-03 15:44:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-03 15:51:09 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-05-03 15:52:27 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-05-03 15:53:33 --> Severity: Warning  --> unlink(/home2/adthrif1/public_html/connect_showcase/files/apps/): Is a directory /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 231
ERROR - 2013-05-03 18:36:23 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-03 18:38:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-03 18:48:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-03 18:48:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-03 19:06:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-03 19:07:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-03 19:08:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-03 20:40:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-03 20:41:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-03 20:42:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-03 20:55:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-03 21:27:57 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-03 21:40:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-03 23:06:09 --> 404 Page Not Found --> favicon.ico
