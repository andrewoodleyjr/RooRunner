<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-04-11 13:33:14 --> 404 Page Not Found --> robots.txt
