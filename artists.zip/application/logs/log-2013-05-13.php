<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-13 01:15:47 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-13 03:59:43 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-13 07:59:46 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-13 08:43:18 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-13 10:05:49 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-13 15:38:36 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-13 16:56:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-13 17:14:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-13 17:20:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-13 17:26:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-13 22:33:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-13 22:38:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-13 22:39:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-13 22:39:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-13 22:40:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-13 22:58:02 --> Severity: Notice  --> Undefined index: description /home2/adthrif1/public_html/artists/application/models/model_apps.php 265
ERROR - 2013-05-13 22:58:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-13 22:58:07 --> Severity: Notice  --> Undefined index: description /home2/adthrif1/public_html/artists/application/models/model_apps.php 265
ERROR - 2013-05-13 22:58:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-13 22:58:17 --> Severity: Notice  --> Undefined index: description /home2/adthrif1/public_html/artists/application/models/model_apps.php 265
ERROR - 2013-05-13 22:58:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-13 22:58:19 --> Severity: Notice  --> Undefined index: description /home2/adthrif1/public_html/artists/application/models/model_apps.php 265
ERROR - 2013-05-13 22:58:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-13 22:58:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-13 22:58:45 --> Severity: Notice  --> Undefined index: description /home2/adthrif1/public_html/artists/application/models/model_apps.php 265
ERROR - 2013-05-13 22:58:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-13 22:58:52 --> Severity: Notice  --> Undefined index: description /home2/adthrif1/public_html/artists/application/models/model_apps.php 265
ERROR - 2013-05-13 22:58:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-13 22:58:55 --> Severity: Notice  --> Undefined index: description /home2/adthrif1/public_html/artists/application/models/model_apps.php 265
ERROR - 2013-05-13 22:58:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-13 23:34:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-13 23:34:23 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-13 23:34:28 --> Severity: Notice  --> Undefined index: description /home2/adthrif1/public_html/artists/application/models/model_apps.php 265
ERROR - 2013-05-13 23:34:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-13 23:35:35 --> Severity: Notice  --> Undefined index: description /home2/adthrif1/public_html/artists/application/models/model_apps.php 265
ERROR - 2013-05-13 23:35:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-13 23:35:39 --> Severity: Notice  --> Undefined index: description /home2/adthrif1/public_html/artists/application/models/model_apps.php 265
ERROR - 2013-05-13 23:35:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-13 23:35:42 --> Severity: Notice  --> Undefined index: description /home2/adthrif1/public_html/artists/application/models/model_apps.php 265
ERROR - 2013-05-13 23:35:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-13 23:37:15 --> 404 Page Not Found --> favicon.ico
