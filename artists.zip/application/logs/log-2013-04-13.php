<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-04-13 12:34:19 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-13 15:57:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-13 15:57:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-13 15:58:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-13 15:58:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-13 15:58:50 --> 404 Page Not Found --> images
ERROR - 2013-04-13 15:58:50 --> 404 Page Not Found --> images
ERROR - 2013-04-13 15:58:50 --> 404 Page Not Found --> images
ERROR - 2013-04-13 15:58:51 --> 404 Page Not Found --> images
ERROR - 2013-04-13 15:58:53 --> 404 Page Not Found --> images
ERROR - 2013-04-13 15:58:54 --> 404 Page Not Found --> images
ERROR - 2013-04-13 15:58:56 --> 404 Page Not Found --> .png
ERROR - 2013-04-13 15:58:56 --> 404 Page Not Found --> scripts
ERROR - 2013-04-13 15:58:56 --> 404 Page Not Found --> scripts
ERROR - 2013-04-13 15:58:57 --> 404 Page Not Found --> scripts
ERROR - 2013-04-13 15:58:57 --> 404 Page Not Found --> scripts
ERROR - 2013-04-13 15:58:57 --> 404 Page Not Found --> scripts
ERROR - 2013-04-13 15:58:57 --> 404 Page Not Found --> scripts
ERROR - 2013-04-13 15:58:58 --> 404 Page Not Found --> scripts
ERROR - 2013-04-13 15:58:58 --> 404 Page Not Found --> .png
ERROR - 2013-04-13 15:59:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-13 16:53:35 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-13 19:58:23 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-13 20:00:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-13 20:03:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-13 20:04:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-13 20:44:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-13 20:44:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-13 20:46:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-13 20:50:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-13 20:50:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-13 21:09:21 --> Severity: Notice  --> Undefined property: stdClass::$id /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 254
ERROR - 2013-04-13 21:09:21 --> Severity: Notice  --> Undefined property: stdClass::$id /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 256
ERROR - 2013-04-13 21:09:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2013-04-13 21:46:44 --> 404 Page Not Found --> favicon.ico
