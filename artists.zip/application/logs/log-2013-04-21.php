<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-04-21 15:16:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-21 15:16:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-21 15:16:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-21 15:17:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-21 15:19:31 --> Severity: Warning  --> unlink(/home2/adthrif1/public_html/connect_showcase/files/apps/): Is a directory /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 231
ERROR - 2013-04-21 15:20:51 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-04-21 17:16:57 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-21 20:43:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-21 20:43:08 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
