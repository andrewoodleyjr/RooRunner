<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-25 02:56:30 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-25 08:16:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-25 08:16:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-25 08:20:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-25 10:23:29 --> Severity: Notice  --> Undefined property: stdClass::$id /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 254
ERROR - 2013-05-25 10:23:29 --> Severity: Notice  --> Undefined property: stdClass::$id /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 256
ERROR - 2013-05-25 10:23:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2013-05-25 16:48:08 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-25 22:17:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-25 22:17:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-25 22:17:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-25 22:31:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-25 22:31:05 --> 404 Page Not Found --> favicon.ico
