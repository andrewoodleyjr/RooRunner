<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-14 00:09:27 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-14 02:01:56 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-14 13:31:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-14 13:31:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-14 16:28:49 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-14 19:50:09 --> APN: debugPayload response - status_code:8 => Invalid token
ERROR - 2013-05-14 19:50:09 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/models/model_apps.php 933
ERROR - 2013-05-14 19:50:16 --> APN: debugPayload response - status_code:8 => Invalid token
ERROR - 2013-05-14 19:50:16 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/models/model_apps.php 933
ERROR - 2013-05-14 21:17:32 --> 404 Page Not Found --> robots.txt
