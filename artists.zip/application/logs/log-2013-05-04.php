<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-04 02:22:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:07:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:08:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:10:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:10:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:11:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:12:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:12:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:12:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:13:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:13:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:15:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:15:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:17:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:17:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:17:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:18:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:19:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:19:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:23:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:23:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:23:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:23:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:26:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:31:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:31:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:31:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:45:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:45:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:46:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:46:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:48:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:48:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:48:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:48:17 --> 404 Page Not Found --> app/10004
ERROR - 2013-05-04 03:48:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:58:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:58:25 --> Severity: 4096  --> Object of class CI_DB_mysql_result could not be converted to string /home2/adthrif1/public_html/artists/application/controllers/manage.php 67
ERROR - 2013-05-04 03:58:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 03:58:25 --> 404 Page Not Found --> process
ERROR - 2013-05-04 03:58:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:01:45 --> Severity: Notice  --> Undefined variable: query /home2/adthrif1/public_html/artists/application/controllers/manage.php 63
ERROR - 2013-05-04 04:01:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:01:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:01:53 --> Severity: Notice  --> Undefined variable: query /home2/adthrif1/public_html/artists/application/controllers/manage.php 63
ERROR - 2013-05-04 04:01:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:01:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:02:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:04:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:04:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:04:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:05:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:05:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:11:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:16:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:16:19 --> 404 Page Not Found --> process
ERROR - 2013-05-04 04:16:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:16:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:18:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:18:30 --> 404 Page Not Found --> process/0
ERROR - 2013-05-04 04:18:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:18:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:18:35 --> 404 Page Not Found --> process/index
ERROR - 2013-05-04 04:18:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:19:15 --> 404 Page Not Found --> process/index
ERROR - 2013-05-04 04:19:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:19:22 --> 404 Page Not Found --> process/index
ERROR - 2013-05-04 04:19:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:20:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:20:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:20:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:20:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:20:14 --> 404 Page Not Found --> process/0
ERROR - 2013-05-04 04:20:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:38:56 --> 404 Page Not Found --> process/0
ERROR - 2013-05-04 04:38:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:38:58 --> 404 Page Not Found --> process/index
ERROR - 2013-05-04 04:38:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:39:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:39:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:39:04 --> 404 Page Not Found --> process/0
ERROR - 2013-05-04 04:39:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:39:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:44:19 --> 404 Page Not Found --> process/0
ERROR - 2013-05-04 04:44:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:44:22 --> 404 Page Not Found --> process/index
ERROR - 2013-05-04 04:44:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:46:53 --> 404 Page Not Found --> process/index
ERROR - 2013-05-04 04:46:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:46:56 --> 404 Page Not Found --> process/index
ERROR - 2013-05-04 04:46:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:46:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:47:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:47:00 --> 404 Page Not Found --> process/0
ERROR - 2013-05-04 04:47:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:47:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:48:37 --> 404 Page Not Found --> process/index
ERROR - 2013-05-04 04:48:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:48:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:49:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:49:04 --> 404 Page Not Found --> process/0
ERROR - 2013-05-04 04:49:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:50:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:52:11 --> 404 Page Not Found --> process/index
ERROR - 2013-05-04 04:52:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:52:14 --> 404 Page Not Found --> process/index
ERROR - 2013-05-04 04:52:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:52:17 --> 404 Page Not Found --> process/index
ERROR - 2013-05-04 04:52:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:53:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:53:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:53:18 --> 404 Page Not Found --> process/0
ERROR - 2013-05-04 04:53:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:53:23 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:53:33 --> 404 Page Not Found --> settings
ERROR - 2013-05-04 04:53:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:54:49 --> 404 Page Not Found --> process/index
ERROR - 2013-05-04 04:54:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:54:51 --> 404 Page Not Found --> process/index
ERROR - 2013-05-04 04:54:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:56:16 --> 404 Page Not Found --> process/index
ERROR - 2013-05-04 04:56:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 04:56:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 05:03:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 05:12:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 05:12:43 --> 404 Page Not Found --> process/0
ERROR - 2013-05-04 05:12:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 05:12:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 05:21:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 05:21:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 05:21:44 --> 404 Page Not Found --> process/0
ERROR - 2013-05-04 05:21:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 05:21:48 --> Severity: Notice  --> Undefined property: process::$model_users /home2/adthrif1/public_html/artists/application/controllers/process.php 70
ERROR - 2013-05-04 05:21:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 05:24:41 --> Severity: Notice  --> Undefined property: process::$model_users /home2/adthrif1/public_html/artists/application/controllers/process.php 70
ERROR - 2013-05-04 05:24:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 05:26:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 05:27:22 --> 404 Page Not Found --> process/0
ERROR - 2013-05-04 05:27:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 05:27:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 05:30:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 05:30:05 --> 404 Page Not Found --> process/0
ERROR - 2013-05-04 05:30:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 05:30:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 05:31:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 05:31:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 05:48:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 05:48:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 08:43:13 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-04 10:32:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 11:12:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 11:12:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 13:11:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 13:11:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 13:52:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 13:52:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 14:10:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 14:39:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 14:39:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 14:39:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 14:39:09 --> 404 Page Not Found --> iphone3.mp4
ERROR - 2013-05-04 14:56:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 15:03:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 15:03:08 --> Severity: Notice  --> Undefined variable: submitted /home2/adthrif1/public_html/artists/application/controllers/manage.php 73
ERROR - 2013-05-04 15:03:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 15:20:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 15:36:50 --> 404 Page Not Found --> images
ERROR - 2013-05-04 15:37:09 --> 404 Page Not Found --> images
ERROR - 2013-05-04 15:38:12 --> 404 Page Not Found --> images
ERROR - 2013-05-04 15:38:28 --> 404 Page Not Found --> images
ERROR - 2013-05-04 15:38:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 15:38:35 --> 404 Page Not Found --> images
ERROR - 2013-05-04 15:38:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 16:14:56 --> Query error: Unknown column 'id' in 'where clause'
ERROR - 2013-05-04 16:14:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 16:26:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 18:49:56 --> Severity: Notice  --> Undefined property: process::$model_page_entertainment /home2/adthrif1/public_html/artists/application/controllers/process.php 75
ERROR - 2013-05-04 18:49:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 18:51:14 --> 404 Page Not Found --> scripts
ERROR - 2013-05-04 19:09:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 19:18:38 --> Query error: Unknown column 'id' in 'where clause'
ERROR - 2013-05-04 19:18:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 19:20:36 --> Query error: Unknown column 'artist' in 'where clause'
ERROR - 2013-05-04 19:20:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 19:21:19 --> 404 Page Not Found --> scripts
ERROR - 2013-05-04 19:44:30 --> Severity: Notice  --> Undefined property: stdClass::$App_ID /home2/adthrif1/public_html/artists/application/controllers/process.php 68
ERROR - 2013-05-04 19:44:31 --> 404 Page Not Found --> scripts
ERROR - 2013-05-04 19:44:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 20:01:57 --> Severity: Notice  --> Undefined property: stdClass::$App_ID /home2/adthrif1/public_html/artists/application/controllers/process.php 68
ERROR - 2013-05-04 20:01:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 20:01:59 --> Severity: Notice  --> Undefined property: stdClass::$App_ID /home2/adthrif1/public_html/artists/application/controllers/process.php 68
ERROR - 2013-05-04 20:02:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 20:02:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 20:36:17 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-04 21:19:42 --> 404 Page Not Found --> scripts
ERROR - 2013-05-04 21:39:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 21:39:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 21:39:52 --> 404 Page Not Found --> scripts
ERROR - 2013-05-04 22:10:15 --> 404 Page Not Found --> scripts
ERROR - 2013-05-04 22:29:48 --> 404 Page Not Found --> scripts
ERROR - 2013-05-04 22:30:59 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/controllers/process.php 88
ERROR - 2013-05-04 22:30:59 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/controllers/process.php 89
ERROR - 2013-05-04 22:30:59 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/controllers/process.php 90
ERROR - 2013-05-04 22:30:59 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/controllers/process.php 91
ERROR - 2013-05-04 22:30:59 --> Severity: Notice  --> Undefined variable: profile /home2/adthrif1/public_html/artists/application/controllers/process.php 96
ERROR - 2013-05-04 22:30:59 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/controllers/process.php 96
ERROR - 2013-05-04 22:30:59 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/controllers/process.php 96
ERROR - 2013-05-04 22:30:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 22:32:39 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/controllers/process.php 88
ERROR - 2013-05-04 22:32:39 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/controllers/process.php 89
ERROR - 2013-05-04 22:32:39 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/controllers/process.php 90
ERROR - 2013-05-04 22:32:39 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/controllers/process.php 91
ERROR - 2013-05-04 22:32:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 22:40:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 22:54:38 --> 404 Page Not Found --> scripts
ERROR - 2013-05-04 22:54:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 22:54:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 22:54:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 22:54:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 22:54:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 22:54:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 22:55:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 22:55:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 22:55:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 22:55:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 22:55:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 22:55:07 --> 404 Page Not Found --> scripts
ERROR - 2013-05-04 22:55:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 22:55:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 22:55:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 22:55:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:04:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:04:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:04:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:04:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:04:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:04:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:04:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:04:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:04:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:04:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:04:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:04:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:04:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:04:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:04:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:04:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:04:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:04:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:04:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:06:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:14:44 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-04 23:15:49 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-04 23:16:24 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-04 23:41:56 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-04 23:42:00 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-04 23:44:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:44:09 --> Severity: Notice  --> Undefined variable: submitted /home2/adthrif1/public_html/artists/application/controllers/manage.php 73
ERROR - 2013-05-04 23:44:10 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-04 23:44:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:44:11 --> 404 Page Not Found --> scripts
ERROR - 2013-05-04 23:44:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:44:18 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-04 23:45:34 --> Severity: Notice  --> Undefined variable: submitted /home2/adthrif1/public_html/artists/application/controllers/manage.php 73
ERROR - 2013-05-04 23:45:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:45:35 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-04 23:45:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:45:38 --> Severity: Notice  --> Undefined variable: submitted /home2/adthrif1/public_html/artists/application/controllers/manage.php 73
ERROR - 2013-05-04 23:45:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:45:38 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-04 23:45:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:45:42 --> Severity: Notice  --> Undefined variable: submitted /home2/adthrif1/public_html/artists/application/controllers/manage.php 73
ERROR - 2013-05-04 23:45:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:45:43 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-04 23:45:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:45:45 --> Severity: Notice  --> Undefined variable: submitted /home2/adthrif1/public_html/artists/application/controllers/manage.php 73
ERROR - 2013-05-04 23:45:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:45:45 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-04 23:45:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:54:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:54:14 --> Severity: Notice  --> Undefined variable: submitted /home2/adthrif1/public_html/artists/application/controllers/manage.php 74
ERROR - 2013-05-04 23:54:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:54:15 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-04 23:54:16 --> 404 Page Not Found --> scripts
ERROR - 2013-05-04 23:54:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:55:15 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-04 23:55:45 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-04 23:55:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:55:53 --> Severity: Notice  --> Undefined variable: submitted /home2/adthrif1/public_html/artists/application/controllers/manage.php 74
ERROR - 2013-05-04 23:55:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:55:54 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-04 23:55:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:56:02 --> Severity: Notice  --> Undefined variable: submitted /home2/adthrif1/public_html/artists/application/controllers/manage.php 74
ERROR - 2013-05-04 23:56:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:56:03 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-04 23:56:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:56:06 --> Severity: Notice  --> Undefined variable: submitted /home2/adthrif1/public_html/artists/application/controllers/manage.php 74
ERROR - 2013-05-04 23:56:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:56:07 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-04 23:56:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:56:12 --> Severity: Notice  --> Undefined variable: submitted /home2/adthrif1/public_html/artists/application/controllers/manage.php 74
ERROR - 2013-05-04 23:56:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:56:12 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-04 23:56:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:56:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:56:28 --> Severity: Notice  --> Undefined variable: submitted /home2/adthrif1/public_html/artists/application/controllers/manage.php 74
ERROR - 2013-05-04 23:56:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:56:29 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-04 23:56:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:56:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:56:31 --> Severity: Notice  --> Undefined variable: submitted /home2/adthrif1/public_html/artists/application/controllers/manage.php 74
ERROR - 2013-05-04 23:56:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:56:32 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-04 23:56:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:57:10 --> Severity: Notice  --> Undefined variable: submitted /home2/adthrif1/public_html/artists/application/controllers/manage.php 74
ERROR - 2013-05-04 23:57:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:57:11 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-04 23:57:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:57:13 --> Severity: Notice  --> Undefined variable: submitted /home2/adthrif1/public_html/artists/application/controllers/manage.php 74
ERROR - 2013-05-04 23:57:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-04 23:57:13 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 181
ERROR - 2013-05-04 23:57:14 --> 404 Page Not Found --> favicon.ico
