<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of manage
 *
 * @author noahglaser
 */
require_once ('check.php');
class manage extends check{

	public $submitted;
    public function __construct() {
        parent::__construct();
    }
    
    public function faq(){
        
        try{
        
           $menuArray = array();
           $menu = '<li><a href="/manage/" style="color:">Home</a></li>
              <li ><a href="/setting/">Settings</a></li>
              <li class="active"><a href="/manage/faq">Help</a></li>
              <li><a href="/main/logout">Sign Out</a></li>';
           $menuArray['menu'] = $menu;
           $header = array();
              $header['stylesheets'] = '<link href="/scripts/css/faq.css" rel="stylesheet" media="all" type="text/css" />';
              $header['title'] = 'Shwcase Connect &middot; FAQs';
              $this->load->model('model_faq');
              
              
           $this->load->view('header', $header);
           $this->load->view('menu', $menuArray);
           $this->load->view('main/faq', $this->model_faq->getYoutubePlayList());
           $this->load->view('footer');
           
        }
        catch(Exception $e){
            $this->error($e->getMessage());
        }
    }   
	public $App_ID;

    public function App_Process(){
		
		$this->load->library('general_library');
        $gl = new general_library();
        $this->App_ID = $gl->getUserAppID($this->session_data);	
		$App_ID= $this->App_ID;
		
		
		//We will then check if the user has started creating their app. 
		//And show them to where ever they left off. 
		//Steps 1 - 7 by going to the database first...
		  
		$this->db->where('App_ID', $App_ID);
        $query_users = $this->db->get('applications');					  
		 
			if($query_users->num_rows != 1):
               
          		else: 
					foreach ($query_users->result() as $row)
					{
					   $submitted = $row->submitted;
					}    
			endif;
			
		
		if($submitted == 0):
			 $this->load->helper('url');
             redirect('/process/', 'refresh');
		endif;
	}
    
    public function index(){
		
		//$this->App_Process();
		//This is temporary... while we fix the charts and banking section
		$this->load->helper('url');
		redirect('/app/', 'refresh');
     
        try{
              $home = array('firstname' => $this->session_data['firstname']);
              $header['stylesheets'] = '<link href="/scripts/css/manage.css" rel="stylesheet" media="all" type="text/css" />';
              $header['title'] = 'Shwcase Connect &middot; Member';
                          $menuArray = array();
              $menuArray['menu']= '<li><a href="/manage/" style="color:">Home</a></li>
                        <li ><a href="/setting/">Settings</a></li>
                        <li><a href="/manage/faq">Help</a></li>
                        <li><a href="/logout/">Sign Out</a></li>';           

              $this->load->view('header', $header);
              $this->load->view('menu', $menuArray);
              $this->load->view('main/home', $home);
              $this->load->view('footer');
        }
    catch(Exception $e){
        $this->error("Error loading the page.");
    }
    }
    
    
}

?>