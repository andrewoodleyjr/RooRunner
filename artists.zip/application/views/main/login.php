<br />
<div class="container">

      <form class="form-signin" style="background-color:#000; opacity:0.8; margin-top: 40px;" method="post" action="/main/login/">
        <h3 class="form-signin-heading" style="color:#666; text-align:center; text-shadow:0px 2px 2px 0px #000;">Artist Portal</h3>
        <input type="text" name="email" class="input-block-level" value="<?php if(isset($email)){echo $email;} ?>" placeholder="Email address">
        <input type="password" name="password" class="input-block-level" value="<?php if(isset($password)){echo $password;} ?>" placeholder="Password">
        <button class="btn-danger btn-large btn-primary" type="submit" name="submit" style="width:100%">Sign in</button>
        <br><br>
        <?php if(isset($error)){echo $error;}?>
        <a href="/main/forgetpassword/" style="color:#666;">Forgot Password</a>
      
      </form>
    </div>