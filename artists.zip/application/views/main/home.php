  <div class="container">
			<br />
      <!-- Main hero unit for a primary marketing message or call to action -->
      <div class="hero-unit"  id="general_div_maincontent" >
        <h1 class="header_color" >Hey <?php if(isset($firstname)){echo $firstname; } ?>!</h1>
        <p >Welcome to Shwcase. Here you can create apps, manage content, track sales and view banking information reguarding your mobile applications.</p>
        <br />
        <div id="manage_thumb_container">
            <ul id="manage_thumbnails" class="thumbnails" >
                <li class="span3">
                    <a href="/app/" class="thumbnail">
                        <img src="/images/MainBtn/manage.png" alt>
                    </a>
                </li>
                <li class="span3">
                    <a href="/charts/" class="thumbnail">
                        <img src="/images/MainBtn/revenue.png" alt>
                    </a>
                </li>
                <li class="span3">
                    <a href="/banking/" class="thumbnail">
                        <img src="/images/MainBtn/agree.png" alt>
                    </a>
                </li>
     
            </ul>
        </div>
        
      </div>
</div>
