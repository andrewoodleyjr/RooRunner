<div class="container"   >
        
      <!-- Main hero unit for a primary marketing message or call to action -->
    <div class="hero-unit" id="general_div_maincontent" style="margin-left: 5%; width: 80%; margin-right: 5%; margin-top: 40px;">
      
        <h1 >Edit Application Info</h1>
        <p>Here you can edit the information displayed in the App Store for your mobile application.
        </p>
     <br />
        <div class="row-fluid tab-pane active fade in" id="invoice" >
                           <form name="edit_form" action="/app/pay_change" enctype="multipart/form-data" method="post">

                               
                                  <div class="span4">
                    <label>App's Icon Image: </label> 

                    <input id="icon_picture" name="icon_picture" type="file" style="display:visible;">
                    
                    <!--<div  class="input-append">
                        <input style="width: 100px;" id="icon" class="input-large" type="text">
                        <a class="btn" onclick="$('input[id=icon_picture]').click();">Browse</a>
                    </div> -->             
                    <br />  
                    <img src='<?php if(isset($icon)) echo $icon; ?>' class='img-rounded' style="height: 150px; width: 150px;" />
                    <label>Recommended Size: 1024px x 1024px </label>
                    <br />
<br />

                    <label>App's Default Image: </label> 
                    <input id="default_picture" name="default_picture" type="file" style="display:visible;">
                   
                    <!-- <div  class="input-append">
                        <input style="width: 100px;" id="default" class="input-large" type="text">
                        <a class="btn" onclick="$('input[id=default_picture]').click();">Browse</a>
                    </div> -->  
                    <br />
                    <img src='<?php if(isset($default)) echo $default; ?>' class='img-rounded' style="height: 225px; width: 150px;" />
                    <label>Recommended Size: 640px x 960px </label>
                    <br />
                </div>
           

           <div class="span7">
           		<div id="input_container">
                    <label>Name: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
                    <input type="text" name="name" placeholder="Type Name" value="<?php if(isset($name)) echo $name; ?>" />
                    <br />
                    <label>Nickname:</label> <input name="nickname" type="text" placeholder="Type Nickname" value="<?php if(isset($nickname)) echo $nickname; ?>" />
                    <br />
                    <label>Keywords:</label> <input name="keywords" type="text" placeholder="Type Keywords" value="<?php if(isset($keywords)) echo $keywords; ?>" maxlength="100" />
                    <br />
                    
                    <label>Description:</label> 
                 
                   <textarea name="description" id="description" placeholder="Change Me">With this app you can stay up to date with all the latest content, be informed, receive notifications and interact with the artist as well as other fans. 

Features 

Music- 
Listen to your favorite artist songs on the go without downloading or searching for music.

Contact- 
Option to email and book for events on the go. 

Events- 
Check tours, and performance dates, times, and locations. With the ability to purchase tickets from the app. 

Pictures- 
Access Pictures with the ability to save photos and keep it moving. 

Social Media- 
Check what is going on with your favorite artist on twitter and facebook. 

411- 
Its everything about the artist in the app just for you. 

Notes- 
Please have wifi for the best performance.<?php /*if(isset($description)) echo $description; */?></textarea>
                    <br />
                    <input type="submit" value="Submit" class="btn btn-large btn-danger" />
                    <br />
                    <br />
					<?php //if(isset($update_message)) echo $update_message; ?> 
                                 </div>      
           </div>
                             </form>

        </div>

     
</div>