<div class="container">
        
      <!-- Main hero unit for a primary marketing message or call to action -->
      <div class="hero-unit" id="general_div_maincontent">
      
       
     
        <div class="row-fluid tab-pane active fade in" id="invoice" >
          
           <div class="span5" >
           
		<img src="/images/faucet.png" class="img-rounded"  />           
		
		

           </div>
           
           
           <div class="span5" >
            	<h2 >What? You Trashed It!</h2>
           	 <p>
           	 	Okay, You have successfully deleted your mobile app. Your users will be notified.
        	</p>
           	
            <a href="/manage/" class="btn btn-large btn-success" id="successBtn">Go Home</a> 
           
           </div>
        
           
        </div>
        
     
</div>