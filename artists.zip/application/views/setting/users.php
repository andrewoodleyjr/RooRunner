<div class="container">
    <br />
    <!-- Main hero unit for a primary marketing message or call to action -->
    <div class="hero-unit" style=" background-color:#000; opacity:.8;">
        <h2 style="color:#060">Settings</h2>
     
      <div class="tabbable "> 
  <ul class="nav nav-tabs">
    <li class='<?php if(isset($tab1)){echo $tab1; }?>' ><a href="#tab1" data-toggle="tab">Account</a></li>
    <li class='<?php if(isset($tab2)){echo $tab2; }?>' ><a href="#tab2" data-toggle="tab">Password</a></li>

  
  </ul>
  <div class="tab-content span9">
    <div class="tab-pane  span4 <?php if(isset($div1)){echo $div1;} ?>" id="tab1">
        <form class="pull-left" method="post" action="" enctype="multipart/form-data" >
        <label>First Name</label>
        <input type="text" name="firstname" value="<?php if(isset($firstname)){echo $firstname;} ?>" />
        <label>Last Name</label>
        <input type="text" name="lastname" value="<?php if(isset($lastname)){echo $lastname;} ?>" />
        <label>Email</label>
        <input type="text" name="email" value="<?php if(isset($email)){echo $email;} ?>" />
        <label>Mobile</label>
        <input type="text" name="mobile" value="<?php if(isset($phone)){echo $phone;} ?>" /><br />
        <button type="submit" name="submitprofile" class="btn btn-success">Save</button>
        </form>
        <br />
        <?php if(isset($userprofileerror)){echo $userprofileerror;}?>
    </div>
    <div class="tab-pane span4 <?php if(isset($div2)){echo $div2;} ?>" id="tab2">
        
        <form class="pull-left" method="post" action="" enctype="multipart/form-data" >
        <label>Old Password</label>
        <input type="password" name="oldpassword" value="" />
        <label>New Password</label>
        <input type="password" name="newpassword" value="" />
        <label>Retype New Password</label>
        <input type="password" name="confirmpassword" value="" /><br />
        <button type="submit" name="submitpass" class="btn btn-success">Save</button>
        </form>
        <br />
        <?php if(isset($userpassworderror)){echo $userpassworderror;}?>

    </div>
      
              <div class="span4 pull-right">
           <h3 style="color:#060">Account</h3>
           <p>
               From here you can change your basic account info.</p>
               <h4 style="color:#060">Tips:</h4>
              
            <p>
            Add your website for when others wish to get in contact with you regarding your application, product or service.
           </p>
            
           
           </div>  
  </div>
</div>
         
        

    </div>
</div>