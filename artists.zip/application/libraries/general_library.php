<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of generalLibrary
 *
 * @author noahglaser
 */
class general_library {

    
    public function __construct() {
        
    }
    
   public function getUserAppID($session)
    {
       try{
    $CI = & get_instance();
    $CI->db->where('artist_id', $session['userid']);
    $query_applications = $CI->db->get('applications');
    if($query_applications->num_rows != 1):
        throw new Exception("Sorry you don't have application anymore, please contact support if you would like to continue.");
        return false;
    endif;
    $result = $query_applications->result();
    return $result[0]->App_ID;
       }
       catch(Exception $e){
           
       }
    }
    
    public function isLoggedInCustomer(){
        
        $CI = & get_instance();

        $CI->load->library('session');
        $session =& $CI->session->all_userdata();
        
        if(!isset($session['logged_in']) || $session['logged_in'] != true):
            return false;
        endif;
        //customer_user
        if(!isset($session['type']) || !((strpos($session['type'], 'artist_user') > -1 )
                || (strpos($session['type'], 'admin') > -1))):
            throw new Exception("You do not have access to the customer area, please sign up as a customer.");
            return false;
        endif;
     
        return $session;
    }
    
       public function send_appication($emailarr) {

            $CI = & get_instance();
            $CI->load->library('email');
            if(!isset($emailarr['from_email'])):
                $emailarr['from_email'] = 'noreply@shwcase.co';
            endif;
            if(!isset($emailarr['from_display'])):
                $emailarr['from_display'] = 'Shwcase';
            endif;
            $config = Array(
                'protocol' => 'smtp',
                'smtp_host' => 'mail.justgoi.com',
                'validation' => TRUE,
                'smtp_timeout' => 30,
                'smtp_port' => 26,
                'smtp_user' => 'test@justgoi.com', // your email
                'smtp_pass' => '$;9c_EDUu~{G', // your email password
                'mailtype' => 'html',
                'charset' => 'utf-8',
                'wordwrap' => TRUE
            );
            
            $this->email->attach($emailarr['path']);



            $email = $emailarr['email'];
            $CI->email->initialize($config);



            $subject = $emailarr['subject'];
            $message = $emailarr['message'];
            $CI->email->from(strtolower($emailarr['from_email']), $emailarr['from_display']);
            $CI->email->to(strtolower($email));

            $CI->email->subject($subject);
            $CI->email->message($message);


            $emial = $CI->email->send(); //returns true if the email was sent
            if ($emial):
                return true;
            else:
                throw new Exception("Email was not sent");

            endif;
       
    }
    
    public function sendEmail($emailarr) {

            $CI = & get_instance();
            $CI->load->library('email');
            if(!isset($emailarr['from_email'])):
                $emailarr['from_email'] = 'noreply@justgoi.com';
            endif;
            if(!isset($emailarr['from_display'])):
                $emailarr['from_display'] = 'Shwcase';
            endif;
            $config = Array(
                'protocol' => 'smtp',
                'smtp_host' => 'mail.justgoi.com',
                'validation' => TRUE,
                'smtp_timeout' => 30,
                'smtp_port' => 26,
                'smtp_user' => 'test@justgoi.com', // your email
                'smtp_pass' => '$;9c_EDUu~{G', // your email password
                'mailtype' => 'html',
                'charset' => 'utf-8',
                'wordwrap' => TRUE
            );

            $email = $emailarr['email'];
            $CI->email->initialize($config);



            $subject = $emailarr['subject'];
            $message = $emailarr['message'];
            $CI->email->from(strtolower($emailarr['from_email']), $emailarr['from_display']);
            $CI->email->to(strtolower($email));

            $CI->email->subject($subject);
            $CI->email->message($message);


            $emial = $CI->email->send(); //returns true if the email was sent
            if ($emial):
                return true;
            else:
                throw new Exception("Email was not sent");

            endif;
       
    }
    
    

    public function generate_key() {
        //generates a random key of letters and numbers
        $chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
        $len = 6;
        $num_chars = strlen($chars);
        $ret = '';
        for ($i = 0; $i < $len; ++$i) {
            $ret .= $chars[mt_rand(0, $num_chars - 1)];
        }
        return $ret;
    }

    public function uploadpic($fileArray) {

        if (isset($fileArray['filename'], $fileArray['folder'], $fileArray['nameOfPostVariable'])):
//$fileArray['nameOfPostVariable']
//$fileArray['filename']
//$fileArray['folder']
//$fileArray['size']
//$fileArray['filetype']
//$fileArray['filename']
            

                if ($_FILES[$fileArray['nameOfPostVariable']]['error'] != 0):
                    throw new Exception("There was an error uploading the file." . $_FILES[$fileArray['nameOfPostVariable']]['error']);
                endif;
                $CI = & get_instance();
                if(!isset($fileArray['size'])):
                    $fileArray['size'] = 6000;
                endif;
                
                if(!isset($fileArray['filetype'])):
                    $fileArray['filetype'] = 'gif|jpg|png';
                endif;
                
               
            $config = array();
            $config['upload_path'] =  $fileArray['folder'];
            $config['allowed_types'] = $fileArray['filetype'];
            $config['max_size'] = $fileArray['size'];
            $config['file_name'] = $fileArray['filename'];
            $config['overwrite'] = true;

            $CI->load->library('upload');
            $CI->upload->initialize($config);

            $uploaded = $CI->upload->do_upload($fileArray['nameOfPostVariable']);
            if ($uploaded):
                return $CI->upload->data();

            else:
                $error =  $CI->upload->display_errors('<p>', '</p>');
                throw new Exception($error);


            endif;
        else:

            throw new Exception("There was an error when uploading the file.");

        endif;
    }

}

?>
