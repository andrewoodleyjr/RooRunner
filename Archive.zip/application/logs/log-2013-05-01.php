<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-01 07:56:33 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-01 08:27:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-01 10:15:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-01 10:18:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-01 12:22:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-01 12:22:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-01 13:26:46 --> 404 Page Not Found --> robots.txt
