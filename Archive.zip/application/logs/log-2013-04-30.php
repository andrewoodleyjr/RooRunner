<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-04-30 13:41:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-30 13:47:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-30 13:58:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-30 17:30:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-30 17:32:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-30 17:32:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-30 19:22:00 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-30 19:32:19 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-30 20:12:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-30 20:12:47 --> 404 Page Not Found --> favicon.ico
