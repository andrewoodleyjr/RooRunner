<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-04-29 00:49:53 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-29 10:48:59 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-29 12:25:58 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-29 19:31:45 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-29 22:35:28 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-29 23:46:13 --> 404 Page Not Found --> robots.txt
