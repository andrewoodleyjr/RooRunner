<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-31 05:18:39 --> 404 Page Not Found --> scripts
ERROR - 2013-05-31 05:18:41 --> 404 Page Not Found --> scripts
ERROR - 2013-05-31 05:18:42 --> 404 Page Not Found --> scripts
ERROR - 2013-05-31 05:18:42 --> 404 Page Not Found --> scripts
ERROR - 2013-05-31 05:18:42 --> 404 Page Not Found --> scripts
ERROR - 2013-05-31 21:54:48 --> Severity: Notice  --> Undefined property: stdClass::$submitted /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 51
ERROR - 2013-05-31 22:54:57 --> 404 Page Not Found --> settings
ERROR - 2013-05-31 22:55:07 --> 404 Page Not Found --> settings
ERROR - 2013-05-31 22:58:26 --> Query error: Unknown column 'submitted' in 'field list'
ERROR - 2013-05-31 22:59:34 --> Query error: Unknown column 'submitted' in 'field list'
ERROR - 2013-05-31 23:31:05 --> Severity: Notice  --> Undefined variable: gl /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/process.php 227
ERROR - 2013-05-31 23:32:36 --> Severity: Notice  --> Undefined variable: _Session /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/process.php 231
ERROR - 2013-05-31 23:32:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2013-05-31 23:32:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/process.php:224) /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Common.php 442
ERROR - 2013-05-31 23:33:39 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/process.php 231
ERROR - 2013-05-31 23:33:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '['userid']' at line 1
ERROR - 2013-05-31 23:33:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Common.php 442
ERROR - 2013-05-31 23:54:59 --> 404 Page Not Found --> setting/as
ERROR - 2013-05-31 23:59:17 --> Severity: 4096  --> Object of class CI_URI could not be converted to string /Applications/MAMP/htdocs/Shwcase_Artist/application/views/setting/users.php 6
ERROR - 2013-05-31 23:59:44 --> Severity: Notice  --> Undefined property: CI_URI::$segment /Applications/MAMP/htdocs/Shwcase_Artist/application/views/setting/users.php 6
