<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-06-06 00:08:01 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 00:08:08 --> Severity: Notice  --> Undefined index: website_ext /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_users.php 105
ERROR - 2013-06-06 00:08:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Common.php 442
ERROR - 2013-06-06 00:09:41 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 00:13:25 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 00:19:14 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 00:19:19 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Output.php 445
ERROR - 2013-06-06 00:19:29 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Output.php 445
ERROR - 2013-06-06 00:19:33 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Output.php 445
ERROR - 2013-06-06 00:22:12 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 00:22:18 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Output.php 445
ERROR - 2013-06-06 00:22:19 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Output.php 445
ERROR - 2013-06-06 00:22:25 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Output.php 445
ERROR - 2013-06-06 00:24:15 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 00:24:17 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Output.php 445
ERROR - 2013-06-06 00:31:13 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 00:31:18 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Output.php 445
ERROR - 2013-06-06 00:31:41 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 00:31:47 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Output.php 445
ERROR - 2013-06-06 00:32:24 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 00:32:29 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Output.php 445
ERROR - 2013-06-06 00:32:47 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 00:32:49 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Output.php 445
ERROR - 2013-06-06 00:32:59 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Output.php 445
ERROR - 2013-06-06 00:33:13 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 00:33:20 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Output.php 445
ERROR - 2013-06-06 00:37:27 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 00:37:32 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Output.php 445
ERROR - 2013-06-06 00:40:37 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 00:40:42 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Output.php 445
ERROR - 2013-06-06 00:40:56 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Output.php 445
ERROR - 2013-06-06 00:41:20 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 00:41:27 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Output.php 445
ERROR - 2013-06-06 00:43:37 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 07:18:56 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 07:21:28 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 07:29:06 --> Severity: Notice  --> Undefined variable: selected_font /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 239
ERROR - 2013-06-06 07:29:07 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 07:29:34 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 07:34:50 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 07:36:54 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 07:37:02 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 07:38:26 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 07:41:10 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 07:42:38 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 07:43:03 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 07:45:00 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 07:45:20 --> Severity: Notice  --> Undefined index: description /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 296
ERROR - 2013-06-06 07:45:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/Shwcase_Artist/system/helpers/url_helper.php 540
ERROR - 2013-06-06 07:46:24 --> Severity: Notice  --> Undefined index: description /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 296
ERROR - 2013-06-06 07:46:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/Shwcase_Artist/system/helpers/url_helper.php 540
ERROR - 2013-06-06 08:05:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/app.php:332) /Applications/MAMP/htdocs/Shwcase_Artist/system/helpers/url_helper.php 540
ERROR - 2013-06-06 08:10:48 --> Severity: Notice  --> Undefined property: stdClass::$website_ext /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_page_entertainment.php 359
ERROR - 2013-06-06 08:10:48 --> Severity: Notice  --> Undefined property: stdClass::$website_ext /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_page_entertainment.php 359
ERROR - 2013-06-06 08:12:41 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 08:17:20 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 08:33:51 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 08:43:01 --> Severity: Notice  --> Undefined variable: web_ext /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 1129
ERROR - 2013-06-06 08:43:01 --> Severity: Notice  --> Undefined variable: web_ext /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 1129
ERROR - 2013-06-06 08:43:07 --> Severity: Notice  --> Undefined variable: web_ext /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 1129
ERROR - 2013-06-06 08:43:07 --> Severity: Notice  --> Undefined variable: web_ext /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 1129
ERROR - 2013-06-06 08:43:09 --> Severity: Notice  --> Undefined variable: web_ext /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 1129
ERROR - 2013-06-06 08:43:09 --> Severity: Notice  --> Undefined variable: web_ext /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 1129
ERROR - 2013-06-06 08:43:38 --> Severity: Notice  --> Undefined variable: web_ext /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 1129
ERROR - 2013-06-06 08:43:38 --> Severity: Notice  --> Undefined variable: web_ext /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 1129
ERROR - 2013-06-06 08:44:25 --> Severity: Notice  --> Undefined variable: web_ext /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 1129
ERROR - 2013-06-06 08:44:25 --> Severity: Notice  --> Undefined variable: web_ext /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 1129
ERROR - 2013-06-06 08:44:26 --> Severity: Notice  --> Undefined variable: web_ext /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 1129
ERROR - 2013-06-06 08:44:26 --> Severity: Notice  --> Undefined variable: web_ext /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 1129
ERROR - 2013-06-06 08:45:14 --> Severity: Notice  --> Undefined variable: web_ext /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 1129
ERROR - 2013-06-06 08:45:14 --> Severity: Notice  --> Undefined variable: web_ext /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 1129
ERROR - 2013-06-06 08:51:06 --> Severity: Notice  --> Undefined index: $web_ext /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 1129
ERROR - 2013-06-06 08:51:07 --> Severity: Notice  --> Undefined index: $web_ext /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 1129
ERROR - 2013-06-06 21:11:26 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 21:13:20 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 21:25:57 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 21:26:47 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 21:27:39 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 21:28:54 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 21:29:09 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 21:30:28 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 21:37:49 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 21:38:39 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 21:38:48 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 21:39:04 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 21:39:47 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 21:40:12 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 21:40:40 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 21:41:03 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 21:41:24 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 21:42:32 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 21:53:17 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 21:58:09 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 21:58:13 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 21:58:26 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 21:58:58 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 21:59:09 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 22:02:23 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 22:02:35 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 22:03:10 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 22:03:36 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 22:03:48 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 22:05:08 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 22:06:12 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 22:06:54 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 22:10:21 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 22:13:44 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 22:14:26 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 22:15:42 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 22:15:46 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 22:30:36 --> 404 Page Not Found --> process/js
ERROR - 2013-06-06 22:43:11 --> 404 Page Not Found --> process/js
