<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-06-08 18:16:36 --> 404 Page Not Found --> process/js
ERROR - 2013-06-08 18:18:49 --> 404 Page Not Found --> checkout/6
ERROR - 2013-06-08 18:23:32 --> 404 Page Not Found --> checkout/6
ERROR - 2013-06-08 18:36:56 --> 404 Page Not Found --> process/js
ERROR - 2013-06-08 18:36:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/checkout.php:43) /Applications/MAMP/htdocs/Shwcase_Artist/system/libraries/Session.php 675
ERROR - 2013-06-08 18:39:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/checkout.php:43) /Applications/MAMP/htdocs/Shwcase_Artist/system/helpers/url_helper.php 540
ERROR - 2013-06-08 18:39:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/checkout.php:43) /Applications/MAMP/htdocs/Shwcase_Artist/system/helpers/url_helper.php 540
ERROR - 2013-06-08 18:39:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/checkout.php:43) /Applications/MAMP/htdocs/Shwcase_Artist/system/helpers/url_helper.php 540
ERROR - 2013-06-08 18:39:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/checkout.php:43) /Applications/MAMP/htdocs/Shwcase_Artist/system/helpers/url_helper.php 540
ERROR - 2013-06-08 18:39:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/checkout.php:43) /Applications/MAMP/htdocs/Shwcase_Artist/system/helpers/url_helper.php 540
ERROR - 2013-06-08 18:40:18 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/checkout.php:43) /Applications/MAMP/htdocs/Shwcase_Artist/system/libraries/Session.php 675
ERROR - 2013-06-08 18:40:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/checkout.php:43) /Applications/MAMP/htdocs/Shwcase_Artist/system/libraries/Session.php 675
ERROR - 2013-06-08 18:40:53 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/checkout.php:43) /Applications/MAMP/htdocs/Shwcase_Artist/system/libraries/Session.php 675
ERROR - 2013-06-08 18:47:14 --> 404 Page Not Found --> process/js
