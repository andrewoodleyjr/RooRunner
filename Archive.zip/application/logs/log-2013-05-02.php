<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-02 06:52:00 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-02 08:15:27 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-02 12:53:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-02 13:04:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-02 13:05:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-02 13:25:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-02 19:40:59 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-02 20:01:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-02 20:04:23 --> Severity: Notice  --> Undefined property: stdClass::$id /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 254
ERROR - 2013-05-02 20:04:23 --> Severity: Notice  --> Undefined property: stdClass::$id /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 256
ERROR - 2013-05-02 20:04:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
