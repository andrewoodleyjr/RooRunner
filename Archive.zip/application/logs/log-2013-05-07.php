<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-07 07:17:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 07:17:40 --> Severity: Notice  --> Undefined variable: submitted /home2/adthrif1/public_html/artists/application/controllers/manage.php 74
ERROR - 2013-05-07 07:17:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 07:17:40 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-07 07:17:41 --> 404 Page Not Found --> js
ERROR - 2013-05-07 07:17:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 07:17:57 --> Severity: Warning  --> Missing argument 1 for process::skip_process() /home2/adthrif1/public_html/artists/application/controllers/process.php 195
ERROR - 2013-05-07 07:17:57 --> Severity: Notice  --> Undefined variable: id /home2/adthrif1/public_html/artists/application/controllers/process.php 199
ERROR - 2013-05-07 07:17:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2013-05-07 07:17:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 10:09:20 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-07 11:08:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 11:10:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 11:13:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 11:13:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 11:47:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 12:17:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 12:18:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 13:26:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 13:27:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 13:27:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 13:45:22 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-05-07 13:46:36 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-05-07 13:47:51 --> Severity: Warning  --> unlink(/home2/adthrif1/public_html/connect_showcase/files/apps/): Is a directory /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 171
ERROR - 2013-05-07 13:47:51 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-05-07 13:47:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 13:48:48 --> Severity: Warning  --> unlink(/home2/adthrif1/public_html/connect_showcase/files/apps/): Is a directory /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 231
ERROR - 2013-05-07 13:49:10 --> Severity: Warning  --> unlink(/home2/adthrif1/public_html/connect_showcase/files/apps/): Is a directory /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 231
ERROR - 2013-05-07 13:51:25 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-05-07 13:53:45 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-07 13:56:12 --> Severity: Warning  --> unlink(/home2/adthrif1/public_html/connect_showcase/files/apps/): Is a directory /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 236
ERROR - 2013-05-07 13:57:19 --> Severity: Notice  --> Undefined variable: position /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 93
ERROR - 2013-05-07 13:57:19 --> Query error: Column 'position' cannot be null
ERROR - 2013-05-07 13:57:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 14:15:48 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-05-07 14:16:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 14:20:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 14:20:52 --> Severity: Warning  --> unlink(/home2/adthrif1/public_html/connect_showcase/files/apps/): Is a directory /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 231
ERROR - 2013-05-07 14:56:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 14:57:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 14:59:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 14:59:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 14:59:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 15:02:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 15:15:14 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-05-07 15:20:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 15:26:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 17:13:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 23:30:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 23:30:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-07 23:48:00 --> 404 Page Not Found --> robots.txt
