<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-04-19 13:21:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 13:29:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 13:31:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 13:33:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 16:13:30 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2013-04-19 16:13:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 16:14:30 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2013-04-19 16:14:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 16:15:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 16:15:09 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2013-04-19 16:15:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 16:15:17 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2013-04-19 16:15:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 16:15:22 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2013-04-19 16:16:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 16:16:00 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2013-04-19 17:47:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 17:47:33 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2013-04-19 17:57:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 17:57:09 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2013-04-19 17:57:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 17:57:21 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2013-04-19 19:00:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 19:05:20 --> Severity: Notice  --> Undefined property: stdClass::$id /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 254
ERROR - 2013-04-19 19:05:20 --> Severity: Notice  --> Undefined property: stdClass::$id /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 256
ERROR - 2013-04-19 19:05:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2013-04-19 20:27:24 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-19 21:58:15 --> 404 Page Not Found --> files
ERROR - 2013-04-19 21:58:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 21:58:20 --> 404 Page Not Found --> files
ERROR - 2013-04-19 21:59:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 21:59:43 --> 404 Page Not Found --> files
ERROR - 2013-04-19 21:59:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 22:00:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 22:11:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 23:30:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 23:44:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 23:45:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 23:55:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 23:56:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 23:56:54 --> 404 Page Not Found --> files
ERROR - 2013-04-19 23:56:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-19 23:56:58 --> 404 Page Not Found --> files
ERROR - 2013-04-19 23:56:58 --> 404 Page Not Found --> favicon.ico
