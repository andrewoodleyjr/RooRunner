<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-06-03 21:08:47 --> Severity: Warning  --> Missing argument 1 for model_users::updatewebsite(), called in /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/setting.php on line 61 and defined /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_users.php 99
ERROR - 2013-06-03 21:08:47 --> Severity: Notice  --> Undefined variable: session /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_users.php 113
ERROR - 2013-06-03 21:08:47 --> Severity: Notice  --> Undefined index: firstname /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_users.php 122
ERROR - 2013-06-03 21:08:47 --> Severity: Notice  --> Undefined index: email /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_users.php 123
ERROR - 2013-06-03 21:09:19 --> Severity: Warning  --> Missing argument 1 for model_users::updatewebsite(), called in /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/setting.php on line 61 and defined /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_users.php 99
ERROR - 2013-06-03 21:09:19 --> Severity: Notice  --> Undefined variable: session /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_users.php 113
ERROR - 2013-06-03 21:09:19 --> Severity: Notice  --> Undefined index: firstname /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_users.php 122
ERROR - 2013-06-03 21:09:19 --> Severity: Notice  --> Undefined index: email /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_users.php 123
ERROR - 2013-06-03 21:09:35 --> Severity: Notice  --> Undefined property: stdClass::$website /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/setting.php 87
ERROR - 2013-06-03 21:11:02 --> Severity: Warning  --> Missing argument 1 for model_users::updatewebsite(), called in /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/setting.php on line 61 and defined /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_users.php 99
ERROR - 2013-06-03 21:11:02 --> Severity: Notice  --> Undefined variable: session /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_users.php 113
ERROR - 2013-06-03 21:11:02 --> Severity: Notice  --> Undefined index: firstname /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_users.php 122
ERROR - 2013-06-03 21:11:02 --> Severity: Notice  --> Undefined index: email /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_users.php 123
ERROR - 2013-06-03 21:13:01 --> Severity: Notice  --> Undefined index: firstname /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_users.php 122
ERROR - 2013-06-03 21:13:01 --> Severity: Notice  --> Undefined index: email /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_users.php 123
ERROR - 2013-06-03 22:13:37 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_charts_for_users.php 200
ERROR - 2013-06-03 22:13:38 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_charts_for_users.php 200
