<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-18 00:00:22 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-18 12:17:18 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-18 13:31:47 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-18 13:47:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-18 13:52:44 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-05-18 14:02:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-18 14:05:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-18 14:05:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-18 14:07:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-18 14:08:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-18 14:09:31 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-05-18 14:11:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-18 14:12:09 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-05-18 14:13:18 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-05-18 14:14:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-18 14:15:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-18 14:16:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-18 18:16:23 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-18 18:17:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-18 18:21:35 --> 404 Page Not Found --> scripts
ERROR - 2013-05-18 18:22:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-18 18:22:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-18 18:24:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-18 20:48:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-18 20:48:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-18 20:55:27 --> Severity: Notice  --> Undefined property: stdClass::$id /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 452
ERROR - 2013-05-18 20:55:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2013-05-18 21:08:06 --> Severity: Notice  --> Undefined property: stdClass::$id /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 254
ERROR - 2013-05-18 21:08:06 --> Severity: Notice  --> Undefined property: stdClass::$id /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 256
ERROR - 2013-05-18 21:08:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
