<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-04-01 01:24:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 01:24:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 01:24:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 01:24:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 01:24:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 03:25:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 03:25:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 04:14:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 04:14:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 04:14:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 04:14:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 04:15:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 04:15:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 04:16:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 04:16:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 04:16:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 04:17:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 04:17:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 04:17:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 04:17:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 04:17:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 04:17:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 04:24:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 04:24:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 05:28:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 05:28:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 05:28:55 --> Unable to load the requested class: email_library
ERROR - 2013-04-01 05:28:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 05:29:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 05:29:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 05:30:36 --> 404 Page Not Found --> scripts
ERROR - 2013-04-01 05:30:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 05:32:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 05:32:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 05:32:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 05:56:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 05:56:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 05:56:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 05:56:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 05:56:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 05:57:31 --> Severity: Notice  --> Undefined variable: result_customer_user /home2/adthrif1/public_html/artists/application/models/model_users.php 86
ERROR - 2013-04-01 05:57:31 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/models/model_users.php 86
ERROR - 2013-04-01 05:57:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 05:58:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 05:59:35 --> Severity: Notice  --> Undefined index: email /home2/adthrif1/public_html/artists/application/models/model_users.php 159
ERROR - 2013-04-01 05:59:36 --> 404 Page Not Found --> scripts
ERROR - 2013-04-01 05:59:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 06:00:38 --> 404 Page Not Found --> scripts
ERROR - 2013-04-01 06:00:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 06:00:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 06:01:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 06:35:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 06:36:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 06:36:02 --> 404 Page Not Found --> scripts
ERROR - 2013-04-01 06:36:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 06:36:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 06:36:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 06:36:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 06:37:01 --> Severity: Warning  --> Missing argument 1 for model_apps::processSubscription(), called in /home2/adthrif1/public_html/artists/application/controllers/app.php on line 315 and defined /home2/adthrif1/public_html/artists/application/models/model_apps.php 358
ERROR - 2013-04-01 06:38:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 06:38:51 --> Severity: Warning  --> Missing argument 1 for model_apps::processSubscription(), called in /home2/adthrif1/public_html/artists/application/controllers/app.php on line 315 and defined /home2/adthrif1/public_html/artists/application/models/model_apps.php 358
ERROR - 2013-04-01 06:38:55 --> Severity: Notice  --> Undefined variable: App_ID /home2/adthrif1/public_html/artists/application/models/model_apps.php 438
ERROR - 2013-04-01 06:38:55 --> Severity: Notice  --> Undefined property: stdClass::$amount /home2/adthrif1/public_html/artists/application/models/model_apps.php 439
ERROR - 2013-04-01 06:38:55 --> Query error: Column 'App_ID' cannot be null
ERROR - 2013-04-01 06:40:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 06:41:17 --> Severity: Warning  --> Missing argument 1 for model_apps::processSubscription(), called in /home2/adthrif1/public_html/artists/application/controllers/app.php on line 315 and defined /home2/adthrif1/public_html/artists/application/models/model_apps.php 358
ERROR - 2013-04-01 06:41:17 --> Severity: Notice  --> Undefined variable: result_sales_item /home2/adthrif1/public_html/artists/application/models/model_apps.php 385
ERROR - 2013-04-01 06:41:17 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/models/model_apps.php 385
ERROR - 2013-04-01 06:41:17 --> Severity: Notice  --> Undefined variable: result_sales_item /home2/adthrif1/public_html/artists/application/models/model_apps.php 386
ERROR - 2013-04-01 06:41:17 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/models/model_apps.php 386
ERROR - 2013-04-01 06:43:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 06:43:59 --> Severity: Warning  --> Missing argument 1 for model_apps::processSubscription(), called in /home2/adthrif1/public_html/artists/application/controllers/app.php on line 315 and defined /home2/adthrif1/public_html/artists/application/models/model_apps.php 358
ERROR - 2013-04-01 06:44:03 --> Severity: Notice  --> Undefined variable: App_ID /home2/adthrif1/public_html/artists/application/models/model_apps.php 437
ERROR - 2013-04-01 06:44:03 --> Severity: Notice  --> Undefined property: stdClass::$amount /home2/adthrif1/public_html/artists/application/models/model_apps.php 438
ERROR - 2013-04-01 06:44:03 --> Query error: Column 'App_ID' cannot be null
ERROR - 2013-04-01 06:44:41 --> Severity: Warning  --> Missing argument 1 for model_apps::processSubscription(), called in /home2/adthrif1/public_html/artists/application/controllers/app.php on line 315 and defined /home2/adthrif1/public_html/artists/application/models/model_apps.php 358
ERROR - 2013-04-01 06:44:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 06:46:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 06:47:03 --> Severity: Notice  --> Undefined property: stdClass::$amount /home2/adthrif1/public_html/artists/application/models/model_apps.php 438
ERROR - 2013-04-01 06:47:03 --> Query error: Column 'credits' cannot be null
ERROR - 2013-04-01 06:48:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 06:51:12 --> Severity: Notice  --> Undefined property: stdClass::$amount /home2/adthrif1/public_html/artists/application/models/model_apps.php 438
ERROR - 2013-04-01 06:51:12 --> Query error: Column 'credits' cannot be null
ERROR - 2013-04-01 06:52:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 06:54:52 --> Severity: Notice  --> Undefined property: stdClass::$amount /home2/adthrif1/public_html/artists/application/models/model_apps.php 438
ERROR - 2013-04-01 06:54:52 --> Query error: Column 'credits' cannot be null
ERROR - 2013-04-01 06:55:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 06:56:04 --> Severity: Notice  --> Undefined property: stdClass::$amount /home2/adthrif1/public_html/artists/application/models/model_apps.php 438
ERROR - 2013-04-01 06:56:04 --> Query error: Column 'credits' cannot be null
ERROR - 2013-04-01 06:58:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 06:59:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:01:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:01:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:01:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:01:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:02:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:02:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:02:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:02:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:05:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:05:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:05:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:06:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:06:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:07:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:07:06 --> Query error: Unknown column 'artist.id' in 'where clause'
ERROR - 2013-04-01 07:16:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:17:21 --> Query error: Unknown column 'artist.id' in 'where clause'
ERROR - 2013-04-01 07:19:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:19:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:22:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:22:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:24:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:24:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:28:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:28:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:28:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:28:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:29:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:29:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:30:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:30:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:33:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:33:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:33:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:33:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:34:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:43:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:49:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:49:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 07:50:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:03:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:03:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:03:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:03:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:03:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:04:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:04:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:04:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:04:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:04:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:04:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:04:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:04:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:05:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:05:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:05:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:05:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:06:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:06:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:09:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:09:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:09:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:09:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:09:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:09:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:09:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:11:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:11:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:11:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:11:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:11:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:13:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:19:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:19:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:23:42 --> Severity: Warning  --> require(pdf/fpdf.php): failed to open stream: No such file or directory /home2/adthrif1/public_html/artists/application/libraries/mypdf.php 5
ERROR - 2013-04-01 08:23:42 --> Severity: Warning  --> require(pdf/fpdf.php): failed to open stream: No such file or directory /home2/adthrif1/public_html/artists/application/libraries/mypdf.php 5
ERROR - 2013-04-01 08:23:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:23:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:23:44 --> Severity: Warning  --> require(pdf/fpdf.php): failed to open stream: No such file or directory /home2/adthrif1/public_html/artists/application/libraries/mypdf.php 5
ERROR - 2013-04-01 08:23:44 --> Severity: Warning  --> require(pdf/fpdf.php): failed to open stream: No such file or directory /home2/adthrif1/public_html/artists/application/libraries/mypdf.php 5
ERROR - 2013-04-01 08:23:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:26:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:26:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:26:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:27:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:27:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:27:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:27:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:27:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:27:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:27:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:27:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:27:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:28:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:28:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:28:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:28:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:29:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:32:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:32:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:32:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:32:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:34:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:34:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:34:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:34:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:35:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:37:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:37:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:39:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:42:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:44:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:44:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:47:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:47:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:47:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:49:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:52:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:52:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:52:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:53:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:53:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:57:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 08:58:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 09:02:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 09:06:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 09:12:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 09:17:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 10:15:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 10:15:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 10:38:14 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-01 12:02:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 12:07:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 14:01:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 14:01:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 14:01:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 19:18:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 19:18:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 19:18:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 19:18:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 19:18:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 19:52:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 19:53:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 19:53:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 19:54:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 19:54:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 19:56:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 19:56:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 19:57:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 19:57:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 19:57:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 19:58:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 19:58:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 19:58:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 19:58:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:00:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:00:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:00:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:00:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:00:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:00:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:01:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:01:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:03:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:03:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:04:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:05:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:05:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:06:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:06:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:10:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:10:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:10:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:10:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:12:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:12:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:12:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:12:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:12:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:12:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:12:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:12:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:13:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:26:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:26:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:36:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:36:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:36:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:55:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:55:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:55:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:56:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:56:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 20:56:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:16:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:31:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:32:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:32:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:33:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:39:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:40:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:40:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:43:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:43:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:43:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:43:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:46:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:46:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:46:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:47:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:47:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:47:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:47:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:47:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:47:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:47:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:47:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:48:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:48:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:48:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:49:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:49:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:49:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:49:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:49:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:49:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:49:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 21:49:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 22:35:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 22:36:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 22:37:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 22:37:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 22:37:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 22:37:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 22:37:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 22:37:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 22:37:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 22:37:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 22:39:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 22:39:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 22:39:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 22:41:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 22:41:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 22:45:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 22:52:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-01 22:52:17 --> 404 Page Not Found --> favicon.ico
