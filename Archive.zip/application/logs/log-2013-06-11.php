<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-06-11 04:06:11 --> 404 Page Not Found --> manage/profile
ERROR - 2013-06-11 04:09:01 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 04:09:01 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:09:01 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:09:01 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:09:22 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 04:09:22 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:09:22 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:09:22 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:09:37 --> 404 Page Not Found --> manage/profile
ERROR - 2013-06-11 04:09:40 --> 404 Page Not Found --> manage/profile
ERROR - 2013-06-11 04:15:34 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 04:15:34 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:15:34 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:15:34 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:16:15 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 04:16:15 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:16:15 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:16:15 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:01 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:01 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:01 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:01 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:01 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:01 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:01 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:02 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:02 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:02 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:02 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:02 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:02 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:02 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:02 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:02 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:03 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:03 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:03 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:04 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 04:17:04 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:04 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:04 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:06 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:06 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:06 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:06 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:06 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:06 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:06 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:06 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:06 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:08 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:08 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:08 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:08 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:08 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:08 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:08 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:08 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:08 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:16 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 04:17:16 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:16 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:18 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:18 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:18 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:18 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:18 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:18 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:18 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:18 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:18 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:18 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:18 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:18 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:18 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:19 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:19 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:19 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:19 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:19 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:19 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:19 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:19 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:19 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:19 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:19 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:19 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:17:19 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:23:16 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 04:23:16 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:23:16 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:23:16 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:23:22 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 04:23:22 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:23:22 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:23:22 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:28:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/controllers/manage.php:356) /Applications/MAMP/htdocs/iStand/system/helpers/url_helper.php 540
ERROR - 2013-06-11 04:34:48 --> Severity: Notice  --> Undefined property: manage::$form_errors /Applications/MAMP/htdocs/iStand/application/controllers/manage.php 460
ERROR - 2013-06-11 04:42:23 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 04:42:23 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:42:23 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:42:23 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:43:22 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 04:43:22 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:43:22 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:43:22 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:43:28 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 04:43:28 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:43:28 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:43:28 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 04:57:55 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/iStand/application/views/main/create.php 23
ERROR - 2013-06-11 04:58:32 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:58:51 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:58:51 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:58:51 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:58:51 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:58:51 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:58:51 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:59:21 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:59:21 --> Severity: Warning  --> Illegal string offset 'error' /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:59:21 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:59:21 --> Severity: Warning  --> Illegal string offset 'error' /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:59:21 --> Severity: Warning  --> Illegal string offset 'error' /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:59:21 --> Severity: Warning  --> Illegal string offset 'error' /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:59:21 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:59:21 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:59:21 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:59:35 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:59:35 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:59:35 --> Severity: Warning  --> Illegal string offset 'error' /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:59:35 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:59:35 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:59:36 --> Severity: Warning  --> Illegal string offset 'error' /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:59:36 --> Severity: Warning  --> Illegal string offset 'error' /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:59:36 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:59:36 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:59:36 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:59:36 --> Severity: Warning  --> Illegal string offset 'error' /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:59:36 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:59:36 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 04:59:36 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:00:10 --> Severity: Notice  --> Undefined offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:00:10 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:00:10 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:00:10 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:00:10 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:00:10 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:00:10 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:00:10 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:00:10 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:00:10 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:00:10 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:01:21 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:01:21 --> Severity: Warning  --> Illegal string offset 'error' /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:01:21 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:01:21 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:01:21 --> Severity: Warning  --> Illegal string offset 'error' /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:01:21 --> Severity: Warning  --> Illegal string offset 'error' /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:01:21 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:01:21 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:01:21 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:01:21 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:01:21 --> Severity: Warning  --> Illegal string offset 'error' /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:01:21 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:01:21 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:01:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/controllers/manage.php:459) /Applications/MAMP/htdocs/iStand/system/helpers/url_helper.php 540
ERROR - 2013-06-11 05:02:08 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:02:08 --> Severity: Warning  --> Illegal string offset 'error' /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:02:08 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:02:08 --> Severity: Warning  --> Illegal string offset 'error' /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:02:08 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:02:08 --> Severity: Warning  --> Illegal string offset 'error' /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:02:08 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:02:08 --> Severity: Warning  --> Illegal string offset 'error' /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:02:08 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:03:31 --> Severity: Warning  --> Illegal string offset 'error' /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:03:31 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:03:31 --> Severity: Warning  --> Illegal string offset 'error' /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:03:31 --> Severity: Warning  --> Illegal string offset 'error' /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:03:31 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:03:31 --> Severity: Warning  --> Illegal string offset 'error' /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:03:31 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:03:31 --> Severity: Notice  --> Uninitialized string offset: 0 /Applications/MAMP/htdocs/iStand/application/views/main/create.php 24
ERROR - 2013-06-11 05:07:37 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 05:07:37 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:07:37 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:07:37 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:10:28 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 05:10:28 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:10:28 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:10:28 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:11:49 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 05:11:49 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:11:49 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:11:49 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:25:04 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 05:25:04 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:25:04 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:25:04 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:25:06 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 05:25:06 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:25:06 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:25:06 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:37:43 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 05:37:44 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:37:44 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:37:44 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:37:56 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 05:37:56 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:37:56 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:37:56 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:38:35 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 05:38:35 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:38:35 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:38:35 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:39:27 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/update.php 27
ERROR - 2013-06-11 05:39:27 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/update.php 27
ERROR - 2013-06-11 05:39:27 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/update.php 27
ERROR - 2013-06-11 05:39:27 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/update.php 27
ERROR - 2013-06-11 05:39:40 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/update.php 27
ERROR - 2013-06-11 05:39:40 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/update.php 27
ERROR - 2013-06-11 05:39:40 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/update.php 27
ERROR - 2013-06-11 05:39:40 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/update.php 27
ERROR - 2013-06-11 05:51:57 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 05:51:57 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:51:57 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 05:51:57 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 07:35:49 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 07:35:49 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 07:35:49 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 07:58:27 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 07:58:27 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 07:58:27 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 07:58:27 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 07:58:30 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 07:58:30 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 07:58:30 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 07:58:30 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 07:58:32 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 07:58:32 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 07:58:32 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 07:58:32 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 08:00:37 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 08:00:37 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 08:00:37 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 08:00:37 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 08:00:44 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 08:00:44 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 08:00:44 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 08:00:44 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 08:24:33 --> Query error: Table 'adthrif1_iStand.artists' doesn't exist
ERROR - 2013-06-11 08:24:50 --> Query error: Unknown column 'location' in 'field list'
ERROR - 2013-06-11 08:26:52 --> Query error: Unknown column 'location' in 'field list'
ERROR - 2013-06-11 08:35:58 --> Query error: Unknown column 'location' in 'field list'
ERROR - 2013-06-11 08:36:15 --> Severity: Notice  --> Undefined variable: post /Applications/MAMP/htdocs/iStand/application/controllers/manage.php 612
ERROR - 2013-06-11 08:36:47 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 08:36:47 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 08:36:47 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 08:40:31 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 08:40:31 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 08:40:31 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 08:40:31 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 08:40:46 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 08:40:46 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 08:40:46 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 08:40:46 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 09:13:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:54) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:13:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:54) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:13:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:54) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:13:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:54) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:15:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:54) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:15:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:54) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:15:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:54) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:15:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:54) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:16:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:54) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:16:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:54) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:16:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:54) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:16:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:54) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:16:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:54) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:16:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:54) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:16:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:54) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:16:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:54) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:17:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:101) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:17:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:101) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:17:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:101) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:17:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:101) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:17:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:101) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:17:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:101) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:17:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:101) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:17:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:101) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:18:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:102) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:18:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:102) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:18:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:102) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:18:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:102) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:18:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:102) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:18:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:102) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:18:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:102) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:18:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:102) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:19:01 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:102) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:19:01 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:102) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:19:01 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:102) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:19:01 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:102) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:19:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:100) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:19:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:100) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:19:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:100) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:19:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:100) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:20:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:100) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:21:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:100) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:21:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:100) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:21:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:100) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:21:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:100) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:24:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:98) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:24:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:98) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:24:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:98) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:24:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:98) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:25:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:100) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:26:01 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 09:26:01 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 09:26:01 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 09:26:01 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 09:26:11 --> Severity: Warning  --> Missing argument 1 for model_users::update(), called in /Applications/MAMP/htdocs/iStand/application/models/model_users.php on line 93 and defined /Applications/MAMP/htdocs/iStand/application/models/model_users.php 239
ERROR - 2013-06-11 09:26:11 --> Severity: Warning  --> Missing argument 2 for model_users::update(), called in /Applications/MAMP/htdocs/iStand/application/models/model_users.php on line 93 and defined /Applications/MAMP/htdocs/iStand/application/models/model_users.php 239
ERROR - 2013-06-11 09:26:11 --> Severity: Notice  --> Undefined variable: session /Applications/MAMP/htdocs/iStand/application/models/model_users.php 246
ERROR - 2013-06-11 09:26:11 --> Severity: Notice  --> Undefined index: title /Applications/MAMP/htdocs/iStand/application/models/model_users.php 248
ERROR - 2013-06-11 09:26:11 --> Severity: Notice  --> Undefined index: reward /Applications/MAMP/htdocs/iStand/application/models/model_users.php 249
ERROR - 2013-06-11 09:26:11 --> Severity: Notice  --> Undefined variable: id /Applications/MAMP/htdocs/iStand/application/models/model_users.php 256
ERROR - 2013-06-11 09:26:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2013-06-11 09:26:11 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:27:34 --> Query error: Unknown column 'location' in 'field list'
ERROR - 2013-06-11 09:27:34 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:100) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:27:49 --> Query error: Unknown column 'location' in 'field list'
ERROR - 2013-06-11 09:27:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:100) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 09:28:12 --> Query error: Unknown column 'location' in 'field list'
ERROR - 2013-06-11 09:29:04 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 09:29:04 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 09:29:04 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 09:29:04 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 09:29:15 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 09:29:15 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 09:29:15 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 09:29:15 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 09:29:17 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 09:29:17 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 09:29:17 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 09:29:17 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 11:01:47 --> Severity: Warning  --> Illegal string offset 'userid' /Applications/MAMP/htdocs/iStand/application/models/model_users.php 351
ERROR - 2013-06-11 11:01:59 --> Severity: Warning  --> Illegal string offset 'userid' /Applications/MAMP/htdocs/iStand/application/models/model_users.php 351
ERROR - 2013-06-11 11:02:07 --> Severity: Notice  --> Undefined index: id /Applications/MAMP/htdocs/iStand/application/controllers/manage.php 461
ERROR - 2013-06-11 11:02:24 --> Severity: Notice  --> Undefined index: id /Applications/MAMP/htdocs/iStand/application/controllers/manage.php 461
ERROR - 2013-06-11 11:02:25 --> Severity: Notice  --> Undefined index: id /Applications/MAMP/htdocs/iStand/application/controllers/manage.php 461
ERROR - 2013-06-11 11:02:36 --> Severity: Notice  --> Undefined variable: errors /Applications/MAMP/htdocs/iStand/application/controllers/manage.php 463
ERROR - 2013-06-11 11:02:54 --> Severity: Notice  --> Undefined variable: errors /Applications/MAMP/htdocs/iStand/application/controllers/manage.php 463
ERROR - 2013-06-11 11:03:01 --> Severity: Notice  --> Undefined variable: errors /Applications/MAMP/htdocs/iStand/application/controllers/manage.php 463
ERROR - 2013-06-11 11:03:02 --> Severity: Notice  --> Undefined variable: errors /Applications/MAMP/htdocs/iStand/application/controllers/manage.php 463
ERROR - 2013-06-11 11:03:02 --> Severity: Notice  --> Undefined variable: errors /Applications/MAMP/htdocs/iStand/application/controllers/manage.php 463
ERROR - 2013-06-11 11:03:02 --> Severity: Notice  --> Undefined variable: errors /Applications/MAMP/htdocs/iStand/application/controllers/manage.php 463
ERROR - 2013-06-11 11:03:02 --> Severity: Notice  --> Undefined variable: errors /Applications/MAMP/htdocs/iStand/application/controllers/manage.php 463
ERROR - 2013-06-11 11:03:12 --> Severity: Notice  --> Undefined variable: login /Applications/MAMP/htdocs/iStand/application/controllers/manage.php 467
ERROR - 2013-06-11 11:03:12 --> Severity: Notice  --> Undefined variable: login /Applications/MAMP/htdocs/iStand/application/controllers/manage.php 467
ERROR - 2013-06-11 11:03:12 --> Severity: Notice  --> Undefined variable: login /Applications/MAMP/htdocs/iStand/application/controllers/manage.php 467
ERROR - 2013-06-11 11:03:12 --> Severity: Notice  --> Undefined variable: login /Applications/MAMP/htdocs/iStand/application/controllers/manage.php 467
ERROR - 2013-06-11 11:03:12 --> Severity: Notice  --> Undefined variable: login /Applications/MAMP/htdocs/iStand/application/controllers/manage.php 467
ERROR - 2013-06-11 11:07:23 --> Severity: Notice  --> Undefined variable: edescription /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 106
ERROR - 2013-06-11 11:07:23 --> Severity: Notice  --> Undefined variable: edescription /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 106
ERROR - 2013-06-11 11:07:23 --> Severity: Notice  --> Undefined variable: edescription /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 106
ERROR - 2013-06-11 11:07:23 --> Severity: Notice  --> Undefined variable: edescription /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 106
ERROR - 2013-06-11 11:07:23 --> Severity: Notice  --> Undefined variable: edescription /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 106
ERROR - 2013-06-11 11:24:13 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:24:20 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:24:27 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:25:04 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:25:15 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:25:36 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:26:45 --> Severity: Warning  --> Illegal offset type in isset or empty /Applications/MAMP/htdocs/iStand/system/libraries/Upload.php 147
ERROR - 2013-06-11 11:26:45 --> You did not select a file to upload.
ERROR - 2013-06-11 11:27:09 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:27:33 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:27:41 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:27:50 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:28:04 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:28:16 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:28:22 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:28:30 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:28:42 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:29:20 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:31:18 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:32:57 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:33:15 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:33:57 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:34:32 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:34:47 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:35:35 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:36:20 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:36:48 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:36:53 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:37:02 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:37:17 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:37:32 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:39:46 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 11:39:46 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 11:39:46 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 11:39:46 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 11:39:57 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 11:39:57 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 11:39:57 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 11:39:57 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 11:43:39 --> The upload path does not appear to be valid.
ERROR - 2013-06-11 11:44:45 --> You did not select a file to upload.
ERROR - 2013-06-11 11:45:21 --> You did not select a file to upload.
ERROR - 2013-06-11 11:45:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/libraries/Upload.php:159) /Applications/MAMP/htdocs/iStand/system/libraries/Session.php 675
ERROR - 2013-06-11 11:46:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/libraries/Upload.php:159) /Applications/MAMP/htdocs/iStand/system/libraries/Session.php 675
ERROR - 2013-06-11 11:46:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:468) /Applications/MAMP/htdocs/iStand/system/libraries/Session.php 675
ERROR - 2013-06-11 11:48:50 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:48:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:48:50 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:48:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:48:50 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:48:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:48:50 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:48:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:48:56 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:48:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:48:57 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:48:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:48:57 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:48:57 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:48:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:48:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:49:09 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:49:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:49:09 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:49:09 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:49:09 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:49:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:49:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:49:09 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:49:22 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:49:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:49:22 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:49:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:49:22 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:49:22 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:49:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:49:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:49:53 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:57) /Applications/MAMP/htdocs/iStand/system/libraries/Session.php 675
ERROR - 2013-06-11 11:49:53 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:49:53 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:49:53 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:49:53 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:49:53 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:49:53 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:49:53 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:49:53 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:49:53 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:49:53 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:49:53 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:49:53 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:50:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:57) /Applications/MAMP/htdocs/iStand/system/libraries/Session.php 675
ERROR - 2013-06-11 11:50:00 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:50:00 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:50:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:50:00 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:50:00 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:50:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:50:00 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:50:00 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:50:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:50:00 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:50:00 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:50:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:50:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:57) /Applications/MAMP/htdocs/iStand/system/libraries/Session.php 675
ERROR - 2013-06-11 11:50:06 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:50:06 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:50:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:50:06 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:50:06 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:50:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:50:06 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:50:06 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:50:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:50:06 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:50:06 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:50:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:51:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/models/model_users.php:57) /Applications/MAMP/htdocs/iStand/system/libraries/Session.php 675
ERROR - 2013-06-11 11:51:12 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:51:12 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:51:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:51:12 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:51:12 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:51:12 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:51:12 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:51:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:51:12 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:51:12 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:51:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:51:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:52:00 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:52:00 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:52:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:52:00 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:52:00 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:52:00 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:52:00 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:52:00 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:52:00 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:52:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:52:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:52:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:52:43 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:52:43 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:52:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:52:43 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:52:43 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:52:43 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:52:43 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:52:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:52:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:52:43 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:52:43 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:52:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:55:07 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:55:07 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:55:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:55:07 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:55:07 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:55:07 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 57
ERROR - 2013-06-11 11:55:07 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:55:07 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:55:07 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:55:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:55:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:55:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:55:29 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:55:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:55:29 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:55:29 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:55:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:55:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:55:29 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:55:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:55:36 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:55:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:55:36 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:55:36 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:55:36 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:55:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:55:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:55:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:56:57 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:56:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:56:57 --> 404 Page Not Found --> files
ERROR - 2013-06-11 11:56:58 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:56:58 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:56:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:56:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:56:58 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:56:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:56:58 --> 404 Page Not Found --> files
ERROR - 2013-06-11 11:58:35 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:58:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:58:35 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:58:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:58:35 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:58:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:58:35 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 11:58:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 11:59:51 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 11:59:51 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 11:59:51 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 11:59:51 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 12:00:02 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 12:00:02 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 12:00:02 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 12:00:02 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 12:00:07 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 12:00:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 12:00:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 12:00:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 12:00:09 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 12:00:09 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 12:00:09 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 12:00:09 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 12:15:25 --> Query error: Unknown column 'user_id' in 'where clause'
ERROR - 2013-06-11 12:17:35 --> Query error: Unknown column 'a' in 'where clause'
ERROR - 2013-06-11 12:38:27 --> Severity: Notice  --> Undefined variable: trust2 /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 45
ERROR - 2013-06-11 12:38:27 --> Severity: Notice  --> Undefined variable: trust2 /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 45
ERROR - 2013-06-11 12:38:27 --> Severity: Notice  --> Undefined variable: trust2 /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 45
ERROR - 2013-06-11 12:38:27 --> Severity: Notice  --> Undefined variable: trust2 /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 45
ERROR - 2013-06-11 12:38:27 --> Severity: Notice  --> Undefined variable: trust2 /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 45
ERROR - 2013-06-11 12:38:44 --> Severity: Notice  --> Undefined variable: trust2 /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 46
ERROR - 2013-06-11 12:38:44 --> Severity: Notice  --> Undefined variable: trust2 /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 46
ERROR - 2013-06-11 12:38:44 --> Severity: Notice  --> Undefined variable: trust2 /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 46
ERROR - 2013-06-11 12:38:44 --> Severity: Notice  --> Undefined variable: trust2 /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 46
ERROR - 2013-06-11 12:38:44 --> Severity: Notice  --> Undefined variable: trust2 /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 46
ERROR - 2013-06-11 12:39:06 --> Severity: Notice  --> Undefined variable: trust2 /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 46
ERROR - 2013-06-11 12:39:06 --> Severity: Notice  --> Undefined variable: trust2 /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 46
ERROR - 2013-06-11 12:39:06 --> Severity: Notice  --> Undefined variable: trust2 /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 46
ERROR - 2013-06-11 12:39:06 --> Severity: Notice  --> Undefined variable: trust2 /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 46
ERROR - 2013-06-11 12:39:06 --> Severity: Notice  --> Undefined variable: trust2 /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 46
ERROR - 2013-06-11 12:40:50 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/iStand/application/models/model_users.php 211
ERROR - 2013-06-11 12:40:50 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/iStand/application/models/model_users.php 211
ERROR - 2013-06-11 12:40:50 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/iStand/application/models/model_users.php 211
ERROR - 2013-06-11 12:40:50 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/iStand/application/models/model_users.php 211
ERROR - 2013-06-11 12:40:50 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/iStand/application/models/model_users.php 211
ERROR - 2013-06-11 12:43:06 --> Severity: Notice  --> Undefined variable: reward /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 76
ERROR - 2013-06-11 12:43:06 --> Severity: Notice  --> Undefined variable: reward /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 76
ERROR - 2013-06-11 12:43:06 --> Severity: Notice  --> Undefined variable: reward /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 76
ERROR - 2013-06-11 12:43:06 --> Severity: Notice  --> Undefined variable: reward /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 76
ERROR - 2013-06-11 12:43:06 --> Severity: Notice  --> Undefined variable: reward /Applications/MAMP/htdocs/iStand/application/views/main/profile.php 76
ERROR - 2013-06-11 13:00:47 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:00:47 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:00:47 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:00:47 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:08:07 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:08:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:08:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:08:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:08:08 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:08:09 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:08:09 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:08:09 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:10:29 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:10:29 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:10:29 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:10:29 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:10:32 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:10:32 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:10:32 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:10:32 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:10:59 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:10:59 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:10:59 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:10:59 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:11:12 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 13:11:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 13:11:12 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 13:11:12 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 13:11:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 13:11:12 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 13:11:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 13:11:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 13:11:15 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:11:15 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:11:15 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:11:15 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:13:08 --> Severity: Notice  --> Undefined property: stdClass::$locaton /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 101
ERROR - 2013-06-11 13:13:08 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:13:08 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:13:08 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:13:08 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:13:16 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:13:16 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:13:16 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:13:16 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:13:28 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:13:28 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:13:28 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:13:28 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:14:06 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:14:06 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:14:06 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:14:06 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:18:59 --> Query error: Unknown column 'date' in 'order clause'
ERROR - 2013-06-11 13:19:41 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:19:41 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:19:41 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:19:41 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:21:37 --> Severity: 4096  --> Argument 1 passed to model_page_entertainment::time_ago() must be an instance of DateTime, string given, called in /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php on line 106 and defined /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 68
ERROR - 2013-06-11 13:31:30 --> Severity: Warning  --> Missing argument 2 for model_page_entertainment::get_time_ago_string(), called in /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php on line 167 and defined /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 122
ERROR - 2013-06-11 13:31:30 --> Severity: Warning  --> Missing argument 3 for model_page_entertainment::get_time_ago_string(), called in /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php on line 167 and defined /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 122
ERROR - 2013-06-11 13:31:30 --> Severity: Notice  --> Undefined variable: divisor /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 125
ERROR - 2013-06-11 13:31:30 --> Severity: Warning  --> Division by zero /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 125
ERROR - 2013-06-11 13:31:30 --> Severity: Notice  --> Undefined variable: time_unit /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 131
ERROR - 2013-06-11 13:31:30 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:31:30 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:31:30 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:31:30 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:33:10 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:33:10 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:33:10 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:33:10 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:33:31 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:33:31 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:33:31 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:33:31 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:34:07 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:34:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:34:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:34:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:34:55 --> Query error: Unknown column 'date' in 'field list'
ERROR - 2013-06-11 13:34:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/controllers/manage.php:497) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 13:35:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/application/controllers/manage.php:497) /Applications/MAMP/htdocs/iStand/system/helpers/url_helper.php 540
ERROR - 2013-06-11 13:37:26 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:37:26 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:37:26 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:37:26 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:38:59 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:38:59 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:38:59 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:38:59 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:38:59 --> Query error: Unknown column 'date' in 'order clause'
ERROR - 2013-06-11 13:39:23 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:39:23 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:39:23 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:39:23 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:41:24 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:41:24 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:41:24 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:41:24 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:41:59 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:41:59 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:41:59 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:41:59 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:42:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/update.php 27
ERROR - 2013-06-11 13:42:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/update.php 27
ERROR - 2013-06-11 13:42:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/update.php 27
ERROR - 2013-06-11 13:42:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/update.php 27
ERROR - 2013-06-11 13:42:42 --> Query error: Unknown column 'date' in 'field list'
ERROR - 2013-06-11 13:50:34 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:50:34 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:50:34 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:50:34 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:51:06 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:51:06 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:51:06 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:51:06 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:51:51 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:51:51 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:51:51 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:51:51 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:51:57 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:51:57 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:51:57 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:51:57 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:51:58 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:51:58 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:51:58 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:51:58 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:52:04 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 13:52:04 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:52:04 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 13:52:04 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:05:25 --> Query error: Unknown column 'date' in 'order clause'
ERROR - 2013-06-11 15:06:07 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 15:06:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:06:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:06:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:06:09 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 15:06:09 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:06:09 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:06:09 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:06:17 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 15:06:17 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:06:17 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:06:17 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:06:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/update.php 27
ERROR - 2013-06-11 15:06:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/update.php 27
ERROR - 2013-06-11 15:06:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/update.php 27
ERROR - 2013-06-11 15:06:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/update.php 27
ERROR - 2013-06-11 15:06:35 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 15:06:35 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:06:35 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:06:35 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:06:39 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 15:06:39 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:06:39 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:06:39 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:06:44 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 15:06:44 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:06:44 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:06:44 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:06:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/update.php 27
ERROR - 2013-06-11 15:06:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/update.php 27
ERROR - 2013-06-11 15:06:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/update.php 27
ERROR - 2013-06-11 15:06:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/views/main/update.php 27
ERROR - 2013-06-11 15:07:19 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 15:07:19 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:07:19 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:07:19 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:07:21 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 15:07:21 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:07:21 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:07:21 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:07:25 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 15:07:25 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:07:25 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:07:25 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:07:42 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 15:07:42 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:07:42 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:07:42 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:14:22 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 15:14:22 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:14:22 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:14:22 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:14:29 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 15:14:29 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:14:29 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:14:29 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:28:20 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 351
ERROR - 2013-06-11 15:28:58 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 352
ERROR - 2013-06-11 15:29:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 349
ERROR - 2013-06-11 15:29:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 352
ERROR - 2013-06-11 15:29:33 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 349
ERROR - 2013-06-11 15:29:33 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 352
ERROR - 2013-06-11 15:29:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 352
ERROR - 2013-06-11 15:30:35 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 359
ERROR - 2013-06-11 15:30:53 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:31:17 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 15:31:17 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:31:17 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:31:17 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:34:33 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 15:34:34 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:34:34 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:34:34 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:38:50 --> Severity: Notice  --> Undefined index: description /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 371
ERROR - 2013-06-11 15:40:32 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 15:40:32 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:40:32 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:40:32 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:42:07 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 15:42:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:42:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 15:42:07 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:03:58 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 16:03:58 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:03:58 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:03:58 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:05:55 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 16:05:55 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:05:55 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:05:55 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:05:58 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 16:05:58 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:05:58 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:05:58 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:06:00 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 16:06:00 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:06:00 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:06:00 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:06:03 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 16:06:03 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:06:03 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:06:03 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:14:00 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 16:14:00 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:14:00 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:14:00 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:21:39 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 16:21:39 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:21:39 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:21:39 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:21:41 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 16:21:41 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:21:41 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:21:41 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:21:51 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 16:21:51 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:21:51 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:21:51 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:22:16 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 16:22:16 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:22:16 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:22:16 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:22:20 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:22:20 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:22:20 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:22:20 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:22:20 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:22:20 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:22:20 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:22:20 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:22:20 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:22:21 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:22:21 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:22:21 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:33:17 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:33:17 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:33:17 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:33:17 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:33:17 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:33:17 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:33:17 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:33:17 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:33:17 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:33:17 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:33:40 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:33:40 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:33:40 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:33:40 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:33:40 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:33:40 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:33:40 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:33:40 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:33:40 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:33:40 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:36:17 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:36:17 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:36:42 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:36:42 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:36:42 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:36:42 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:36:42 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:36:42 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:36:42 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:36:42 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:36:42 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:36:42 --> Severity: Notice  --> Undefined variable: time /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 229
ERROR - 2013-06-11 16:42:05 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 16:42:05 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:42:05 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:42:05 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:42:15 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 16:42:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 16:42:15 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 16:42:15 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 16:42:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 16:42:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 16:42:15 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 16:42:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 16:42:20 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 16:42:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 16:42:20 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 16:42:20 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 16:42:20 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 16:42:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 16:42:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 16:42:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 16:42:29 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 16:42:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 16:42:29 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 16:42:29 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 16:42:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 16:42:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 16:42:29 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 16:42:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 16:42:39 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 16:42:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 16:42:39 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 16:42:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 16:42:39 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 16:42:39 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 16:42:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 16:42:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 16:43:10 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 16:43:10 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:43:10 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:43:10 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:43:14 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 16:43:14 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:43:14 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:43:14 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:43:18 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 16:43:18 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:43:18 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:43:18 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:46:06 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 16:46:06 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:46:06 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:46:06 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:46:23 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 16:46:23 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:46:23 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:46:23 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:46:34 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 16:46:34 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:46:34 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:46:34 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 16:52:28 --> Query error: Unknown column 'user_id' in 'where clause'
ERROR - 2013-06-11 17:12:37 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 17:12:37 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 17:12:37 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 17:12:37 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 17:13:32 --> Severity: Notice  --> Undefined variable: image /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 232
ERROR - 2013-06-11 17:13:32 --> Severity: Notice  --> Undefined variable: image /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 232
ERROR - 2013-06-11 17:13:32 --> Severity: Notice  --> Undefined variable: image /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 232
ERROR - 2013-06-11 17:13:32 --> Severity: Notice  --> Undefined variable: image /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 232
ERROR - 2013-06-11 17:13:32 --> Severity: Notice  --> Undefined variable: image /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 232
ERROR - 2013-06-11 17:13:32 --> Severity: Notice  --> Undefined variable: image /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 232
ERROR - 2013-06-11 17:13:32 --> Severity: Notice  --> Undefined variable: image /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 232
ERROR - 2013-06-11 17:13:32 --> Severity: Notice  --> Undefined variable: image /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 232
ERROR - 2013-06-11 17:13:32 --> Severity: Notice  --> Undefined variable: image /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 232
ERROR - 2013-06-11 17:13:32 --> Severity: Notice  --> Undefined variable: image /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 232
ERROR - 2013-06-11 17:13:40 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 17:13:40 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 17:13:40 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 17:13:40 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 18:00:28 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 18:00:28 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 18:00:28 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 18:00:28 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 18:00:29 --> Severity: Notice  --> Undefined variable: image /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 232
ERROR - 2013-06-11 18:00:29 --> Severity: Notice  --> Undefined variable: image /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 232
ERROR - 2013-06-11 18:00:29 --> Severity: Notice  --> Undefined variable: image /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 232
ERROR - 2013-06-11 18:00:29 --> Severity: Notice  --> Undefined variable: image /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 232
ERROR - 2013-06-11 18:00:29 --> Severity: Notice  --> Undefined variable: image /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 232
ERROR - 2013-06-11 18:00:29 --> Severity: Notice  --> Undefined variable: image /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 232
ERROR - 2013-06-11 18:00:29 --> Severity: Notice  --> Undefined variable: image /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 232
ERROR - 2013-06-11 18:00:29 --> Severity: Notice  --> Undefined variable: image /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 232
ERROR - 2013-06-11 18:00:29 --> Severity: Notice  --> Undefined variable: image /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 232
ERROR - 2013-06-11 18:00:29 --> Severity: Notice  --> Undefined variable: image /Applications/MAMP/htdocs/iStand/application/models/model_page_entertainment.php 232
ERROR - 2013-06-11 18:06:37 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 18:06:37 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 18:06:37 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 18:06:37 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 18:19:21 --> 404 Page Not Found --> manage/js
ERROR - 2013-06-11 18:19:21 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 18:19:21 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 18:19:21 --> 404 Page Not Found --> manage/css
ERROR - 2013-06-11 18:21:56 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 18:21:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 18:21:56 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 18:21:56 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 18:21:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 18:21:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
ERROR - 2013-06-11 18:21:56 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/iStand/application/models/model_users.php 58
ERROR - 2013-06-11 18:21:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/iStand/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/iStand/system/core/Common.php 442
