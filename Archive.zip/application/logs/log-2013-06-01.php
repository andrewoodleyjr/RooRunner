<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-06-01 00:03:07 --> Severity: Warning  --> parse_url() expects parameter 1 to be string, object given /Applications/MAMP/htdocs/Shwcase_Artist/application/views/setting/users.php 7
ERROR - 2013-06-01 00:59:43 --> 404 Page Not Found --> setting/tab2
ERROR - 2013-06-01 02:42:47 --> 404 Page Not Found --> app/checkout
ERROR - 2013-06-01 02:45:37 --> 404 Page Not Found --> chart
ERROR - 2013-06-01 04:12:34 --> Severity: Notice  --> Undefined property: app::$model_page_entertainment_website /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Model.php 51
ERROR - 2013-06-01 04:14:05 --> Severity: Notice  --> Undefined property: app::$model_page_entertainment_website /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Model.php 51
ERROR - 2013-06-01 04:18:38 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 04:18:38 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1140
ERROR - 2013-06-01 04:19:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 04:19:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1115
ERROR - 2013-06-01 04:19:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1140
ERROR - 2013-06-01 04:21:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 04:21:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1140
ERROR - 2013-06-01 04:23:24 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 04:23:24 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1140
ERROR - 2013-06-01 04:24:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 04:24:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1140
ERROR - 2013-06-01 04:27:23 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1147
ERROR - 2013-06-01 04:28:09 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1147
ERROR - 2013-06-01 04:38:17 --> Severity: Notice  --> Undefined variable: emailVariables /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 142
ERROR - 2013-06-01 04:39:53 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 04:39:53 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 04:39:53 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 04:39:53 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 04:39:53 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 04:39:53 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 04:39:53 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 04:39:53 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 04:39:53 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 04:39:53 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:39:53 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:42:05 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 04:42:05 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 04:42:05 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 04:42:05 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 04:42:05 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 04:42:05 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 04:42:05 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 04:42:05 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 04:42:05 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 04:42:05 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:42:05 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:46:09 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 04:46:09 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 04:46:09 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 04:46:09 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 04:46:09 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 04:46:09 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 04:46:09 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 04:46:09 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 04:46:09 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 04:46:09 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:46:09 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:46:56 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 04:46:56 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 04:46:56 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 04:46:56 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 04:46:56 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 04:46:56 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 04:46:56 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 04:46:56 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 04:46:56 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 04:46:56 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:46:56 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:50:45 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 04:50:45 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 04:50:45 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 04:50:45 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 04:50:45 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 04:50:45 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 04:50:45 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 04:50:45 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 04:50:45 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 04:50:45 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:50:45 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:51:21 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 04:51:21 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 04:51:21 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 04:51:21 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 04:51:21 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 04:51:21 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 04:51:21 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 04:51:21 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 04:51:21 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 04:51:21 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:51:21 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:51:41 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 04:51:41 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 04:51:41 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 04:51:41 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 04:51:41 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 04:51:41 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 04:51:41 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 04:51:41 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 04:51:41 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 04:51:41 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:51:41 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:52:11 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 04:52:11 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 04:52:11 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 04:52:11 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 04:52:11 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 04:52:11 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 04:52:11 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 04:52:11 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 04:52:11 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 04:52:11 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:52:11 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:53:22 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 04:53:22 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 04:53:22 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 04:53:22 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 04:53:22 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 04:53:22 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 04:53:22 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 04:53:22 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 04:53:22 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 04:53:22 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:53:22 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:53:40 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 04:53:40 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 04:53:40 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 04:53:40 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 04:53:40 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 04:53:40 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 04:53:40 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 04:53:40 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 04:53:40 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 04:53:40 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:53:40 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:53:48 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 04:53:48 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 04:53:48 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 04:53:48 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 04:53:48 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 04:53:48 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 04:53:48 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 04:53:48 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 04:53:48 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 04:53:48 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:53:48 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:53:55 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 04:53:55 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 04:53:55 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 04:53:55 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 04:53:55 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 04:53:55 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 04:53:55 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 04:53:55 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 04:53:55 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 04:53:55 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:53:55 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:54:10 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 04:54:10 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 04:54:10 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 04:54:10 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 04:54:10 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 04:54:10 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 04:54:10 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 04:54:10 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 04:54:10 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 04:54:10 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:54:10 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:54:15 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 04:54:15 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 04:54:15 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 04:54:15 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 04:54:15 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 04:54:15 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 04:54:15 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 04:54:15 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 04:54:15 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 04:54:15 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:54:15 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:54:51 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 04:54:51 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 04:54:51 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 04:54:51 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 04:54:51 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 04:54:51 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 04:54:51 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 04:54:51 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 04:54:51 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 04:54:51 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:54:51 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:55:09 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 04:55:09 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 04:55:09 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 04:55:09 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 04:55:09 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 04:55:09 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 04:55:09 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 04:55:09 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 04:55:09 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 04:55:09 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:55:09 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:57:32 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 04:57:32 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 04:57:32 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 04:57:32 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 04:57:32 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 04:57:32 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 04:57:32 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 04:57:32 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 04:57:32 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 04:57:32 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:57:32 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:58:30 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 04:58:30 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 04:58:30 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 04:58:30 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 04:58:30 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 04:58:30 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 04:58:30 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 04:58:30 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 04:58:30 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 04:58:30 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:58:30 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:59:07 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 04:59:07 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 04:59:07 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 04:59:07 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 04:59:07 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 04:59:07 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 04:59:07 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 04:59:07 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 04:59:07 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 04:59:07 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:59:07 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:59:18 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 04:59:18 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 04:59:18 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 04:59:18 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 04:59:18 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 04:59:18 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 04:59:18 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 04:59:18 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 04:59:18 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 04:59:18 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 04:59:18 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 05:00:20 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined variable: x_value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1116
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 05:03:24 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 05:06:26 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 05:06:26 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 05:06:30 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1111
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1112
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 05:06:30 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 05:07:23 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 05:07:23 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 05:07:23 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 05:07:23 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 05:07:23 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 05:07:23 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 05:07:23 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 05:07:23 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 05:07:23 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 05:07:23 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 05:07:23 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 05:08:02 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 05:08:02 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 05:08:02 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 05:08:02 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 05:08:02 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 05:08:02 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 05:08:02 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 05:08:02 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 05:08:02 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 05:08:02 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 05:08:02 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 05:08:12 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 05:08:12 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 05:08:12 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 05:08:12 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 05:08:12 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 05:08:12 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 05:08:12 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 05:08:12 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 05:08:12 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 05:08:12 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 05:08:12 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 05:12:07 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1163
ERROR - 2013-06-01 05:15:26 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1163
ERROR - 2013-06-01 05:15:33 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1163
ERROR - 2013-06-01 05:15:38 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1163
ERROR - 2013-06-01 05:15:51 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1163
ERROR - 2013-06-01 05:16:05 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1163
ERROR - 2013-06-01 05:18:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1101
ERROR - 2013-06-01 05:18:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1101
ERROR - 2013-06-01 05:18:46 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1164
ERROR - 2013-06-01 05:21:17 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1101
ERROR - 2013-06-01 05:21:17 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1101
ERROR - 2013-06-01 05:21:17 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1164
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:39 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1164
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:41 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1164
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:49 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1164
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:23:53 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1164
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:15 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1164
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:24:46 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1164
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:06 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1164
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:25:19 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1164
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1106
ERROR - 2013-06-01 05:26:28 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1164
ERROR - 2013-06-01 05:27:15 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1143
ERROR - 2013-06-01 05:28:23 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1139
ERROR - 2013-06-01 05:31:15 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1139
ERROR - 2013-06-01 05:33:35 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, string given /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1102
ERROR - 2013-06-01 05:33:35 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1139
ERROR - 2013-06-01 05:33:42 --> Severity: Warning  --> array_keys() expects parameter 1 to be array, string given /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1102
ERROR - 2013-06-01 05:33:42 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1139
ERROR - 2013-06-01 05:34:08 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1139
ERROR - 2013-06-01 05:36:07 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1148
ERROR - 2013-06-01 05:36:13 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1148
ERROR - 2013-06-01 05:36:40 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1148
ERROR - 2013-06-01 05:36:43 --> Severity: Notice  --> Undefined variable: count /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 1148
ERROR - 2013-06-01 05:39:39 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 198
ERROR - 2013-06-01 05:39:39 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 214
ERROR - 2013-06-01 05:39:39 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 219
ERROR - 2013-06-01 05:39:39 --> Severity: Notice  --> Undefined index: head /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 279
ERROR - 2013-06-01 05:39:39 --> Severity: Notice  --> Undefined index: txt /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 297
ERROR - 2013-06-01 05:39:39 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 403
ERROR - 2013-06-01 05:39:39 --> Severity: Notice  --> Undefined index: bar /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 409
ERROR - 2013-06-01 05:39:39 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 427
ERROR - 2013-06-01 05:39:39 --> Severity: Notice  --> Undefined index: top /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 439
ERROR - 2013-06-01 05:39:39 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
ERROR - 2013-06-01 05:39:39 --> Severity: Notice  --> Undefined index: back /Applications/MAMP/htdocs/Shwcase_Artist/application/libraries/General_library.php 500
