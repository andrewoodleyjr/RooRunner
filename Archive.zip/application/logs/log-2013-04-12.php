<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-04-12 11:46:13 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-12 12:07:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-12 12:07:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-12 12:07:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-12 12:08:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-12 15:11:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-12 15:11:53 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-12 18:53:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-12 18:53:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-12 18:54:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-12 20:45:51 --> 404 Page Not Found --> robots.txt
