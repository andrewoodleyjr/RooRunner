<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-06-13 17:15:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/RooRunner/application/controllers/manage.php 494
ERROR - 2013-06-13 17:15:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/RooRunner/application/controllers/manage.php 506
ERROR - 2013-06-13 17:15:53 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/RooRunner/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/RooRunner/system/helpers/url_helper.php 540
ERROR - 2013-06-13 17:16:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/RooRunner/application/controllers/manage.php 494
ERROR - 2013-06-13 17:16:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/RooRunner/application/controllers/manage.php 506
ERROR - 2013-06-13 17:16:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/RooRunner/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/RooRunner/system/helpers/url_helper.php 540
ERROR - 2013-06-13 17:17:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/RooRunner/application/controllers/manage.php 494
ERROR - 2013-06-13 17:17:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/RooRunner/application/controllers/manage.php 506
ERROR - 2013-06-13 17:17:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/RooRunner/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/RooRunner/system/helpers/url_helper.php 540
ERROR - 2013-06-13 17:19:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/RooRunner/application/controllers/manage.php 494
ERROR - 2013-06-13 17:19:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/RooRunner/application/controllers/manage.php 506
ERROR - 2013-06-13 17:19:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/RooRunner/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/RooRunner/system/helpers/url_helper.php 540
ERROR - 2013-06-13 17:19:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/RooRunner/application/controllers/manage.php 494
ERROR - 2013-06-13 17:19:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/RooRunner/application/controllers/manage.php 506
ERROR - 2013-06-13 17:19:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/RooRunner/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/RooRunner/system/helpers/url_helper.php 540
ERROR - 2013-06-13 17:22:46 --> 404 Page Not Found --> manage/message_runners
ERROR - 2013-06-13 17:23:31 --> 404 Page Not Found --> manage/message_runners
ERROR - 2013-06-13 17:24:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/RooRunner/application/controllers/manage.php 494
ERROR - 2013-06-13 17:24:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/RooRunner/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/RooRunner/system/helpers/url_helper.php 540
ERROR - 2013-06-13 18:19:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/RooRunner/application/controllers/manage.php 494
ERROR - 2013-06-13 18:19:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/RooRunner/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/RooRunner/system/helpers/url_helper.php 540
ERROR - 2013-06-13 18:27:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /Applications/MAMP/htdocs/RooRunner/application/controllers/manage.php 495
ERROR - 2013-06-13 18:27:34 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/RooRunner/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/RooRunner/system/helpers/url_helper.php 540
ERROR - 2013-06-13 18:28:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/RooRunner/application/controllers/manage.php:492) /Applications/MAMP/htdocs/RooRunner/system/helpers/url_helper.php 540
ERROR - 2013-06-13 18:28:49 --> 404 Page Not Found --> manage/message_runners
ERROR - 2013-06-13 18:39:16 --> Query error: Table 'adthrif1_iStand.artists' doesn't exist
ERROR - 2013-06-13 18:39:57 --> Query error: Table 'adthrif1_iStand.artists' doesn't exist
ERROR - 2013-06-13 18:41:38 --> Severity: Warning  --> fsockopen(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1689
ERROR - 2013-06-13 18:41:38 --> Severity: Warning  --> fsockopen(): unable to connect to mail.justgoi.com:26 (php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known) /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1689
ERROR - 2013-06-13 18:41:38 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:41:38 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:41:38 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:41:38 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:41:38 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:41:38 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:41:38 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:41:38 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:41:38 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:41:38 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:41:38 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:41:43 --> Severity: Warning  --> fsockopen(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1689
ERROR - 2013-06-13 18:41:43 --> Severity: Warning  --> fsockopen(): unable to connect to mail.justgoi.com:26 (php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known) /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1689
ERROR - 2013-06-13 18:41:43 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:41:43 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:41:43 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:41:43 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:41:43 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:41:43 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:41:43 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:41:43 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:41:43 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:41:43 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:41:43 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:42:34 --> Severity: Warning  --> fsockopen(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1689
ERROR - 2013-06-13 18:42:34 --> Severity: Warning  --> fsockopen(): unable to connect to mail.justgoi.com:26 (php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known) /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1689
ERROR - 2013-06-13 18:42:34 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:42:34 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:42:34 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:42:34 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:42:34 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:42:34 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:42:34 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:42:34 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:42:34 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:42:34 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:42:34 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:43:49 --> Severity: Warning  --> fsockopen(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1689
ERROR - 2013-06-13 18:43:49 --> Severity: Warning  --> fsockopen(): unable to connect to mail.justgoi.com:26 (php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known) /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1689
ERROR - 2013-06-13 18:43:49 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:43:49 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:43:49 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:43:49 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:43:49 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:43:49 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:43:49 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:43:49 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:43:49 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:43:49 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:43:49 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:43:51 --> Severity: Warning  --> fsockopen(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1689
ERROR - 2013-06-13 18:43:51 --> Severity: Warning  --> fsockopen(): unable to connect to mail.justgoi.com:26 (php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known) /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1689
ERROR - 2013-06-13 18:43:51 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:43:51 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:43:51 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:43:51 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:43:51 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:43:51 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:43:51 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:43:51 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:43:51 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:43:51 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:43:51 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:45:17 --> Severity: Warning  --> fsockopen(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1689
ERROR - 2013-06-13 18:45:17 --> Severity: Warning  --> fsockopen(): unable to connect to mail.justgoi.com:26 (php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known) /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1689
ERROR - 2013-06-13 18:45:17 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:45:17 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:45:17 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:45:17 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:45:17 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:45:17 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:45:17 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:45:17 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 18:45:17 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:45:17 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 18:45:17 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 19:03:19 --> Severity: Warning  --> fsockopen(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1689
ERROR - 2013-06-13 19:03:19 --> Severity: Warning  --> fsockopen(): unable to connect to mail.justgoi.com:26 (php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known) /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1689
ERROR - 2013-06-13 19:03:19 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 19:03:19 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 19:03:19 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 19:03:19 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 19:03:19 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 19:03:19 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 19:03:19 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 19:03:19 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 19:03:19 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 19:03:19 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 19:03:19 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 19:11:42 --> 404 Page Not Found --> manage/message_runners
ERROR - 2013-06-13 19:11:50 --> 404 Page Not Found --> manage/message_runners
ERROR - 2013-06-13 19:16:39 --> 404 Page Not Found --> manage/message_runners
ERROR - 2013-06-13 19:27:33 --> Severity: Warning  --> fsockopen(): unable to connect to mail.justgoi.com:26 (Operation timed out) /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1689
ERROR - 2013-06-13 19:27:33 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 19:27:33 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 19:27:33 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 19:27:33 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 19:27:33 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 19:27:33 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 19:27:33 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 19:27:33 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 19:27:33 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 19:27:33 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 19:27:33 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 19:45:44 --> Severity: Warning  --> fsockopen(): php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1689
ERROR - 2013-06-13 19:45:44 --> Severity: Warning  --> fsockopen(): unable to connect to mail.justgoi.com:26 (php_network_getaddresses: getaddrinfo failed: nodename nor servname provided, or not known) /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1689
ERROR - 2013-06-13 19:45:44 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 19:45:44 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 19:45:44 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 19:45:44 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 19:45:44 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 19:45:44 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 19:45:44 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 19:45:44 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 19:45:44 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 19:45:44 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1846
ERROR - 2013-06-13 19:45:44 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/RooRunner/system/libraries/Email.php 1869
ERROR - 2013-06-13 21:59:14 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/RooRunner/application/models/model_users.php 59
ERROR - 2013-06-13 21:59:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/RooRunner/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/RooRunner/system/libraries/Session.php 675
ERROR - 2013-06-13 21:59:21 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/RooRunner/application/models/model_users.php 59
ERROR - 2013-06-13 21:59:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/RooRunner/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/RooRunner/system/libraries/Session.php 675
ERROR - 2013-06-13 21:59:26 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/RooRunner/application/models/model_users.php 59
ERROR - 2013-06-13 21:59:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/RooRunner/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/RooRunner/system/libraries/Session.php 675
ERROR - 2013-06-13 21:59:31 --> Severity: Notice  --> Undefined index: picture /Applications/MAMP/htdocs/RooRunner/application/models/model_users.php 59
ERROR - 2013-06-13 21:59:31 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/RooRunner/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/RooRunner/system/libraries/Session.php 675
ERROR - 2013-06-13 21:59:51 --> 404 Page Not Found --> manage/message_runners
