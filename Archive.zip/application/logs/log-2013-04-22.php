<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-04-22 12:45:52 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-22 14:02:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-22 14:02:45 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2013-04-22 15:25:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-22 15:27:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-22 15:29:32 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-22 15:41:11 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-04-22 15:41:35 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-04-22 15:43:06 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-04-22 15:45:29 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-04-22 15:46:21 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-04-22 15:57:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-22 16:06:48 --> Severity: Warning  --> unlink(/home2/adthrif1/public_html/connect_showcase/files/apps/): Is a directory /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 231
ERROR - 2013-04-22 16:07:10 --> Severity: Warning  --> unlink(/home2/adthrif1/public_html/connect_showcase/files/apps/): Is a directory /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 231
ERROR - 2013-04-22 16:07:34 --> Severity: Warning  --> unlink(/home2/adthrif1/public_html/connect_showcase/files/apps/): Is a directory /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 231
ERROR - 2013-04-22 16:18:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-22 16:18:38 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2013-04-22 16:20:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-22 16:20:03 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2013-04-22 16:20:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-22 16:20:10 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2013-04-22 16:21:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-22 16:21:54 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2013-04-22 16:23:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-22 16:23:32 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2013-04-22 23:52:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-22 23:52:41 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2013-04-22 23:52:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-22 23:52:42 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
