<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-06-04 01:38:29 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_charts_for_users.php 200
ERROR - 2013-06-04 01:38:31 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_charts_for_users.php 200
ERROR - 2013-06-04 01:38:32 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_charts_for_users.php 200
ERROR - 2013-06-04 01:38:32 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_charts_for_users.php 200
ERROR - 2013-06-04 02:16:16 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_charts_for_users.php 200
ERROR - 2013-06-04 02:39:19 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_charts_for_users.php 200
ERROR - 2013-06-04 02:39:29 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_charts_for_users.php 200
ERROR - 2013-06-04 03:09:54 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_charts_for_users.php 200
ERROR - 2013-06-04 03:11:58 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_charts_for_users.php 200
ERROR - 2013-06-04 03:13:52 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_charts_for_users.php 200
ERROR - 2013-06-04 03:15:54 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_charts_for_users.php 200
ERROR - 2013-06-04 03:19:02 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_charts_for_users.php 200
ERROR - 2013-06-04 03:19:03 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_charts_for_users.php 200
ERROR - 2013-06-04 03:19:03 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_charts_for_users.php 200
ERROR - 2013-06-04 03:19:03 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_charts_for_users.php 200
ERROR - 2013-06-04 03:19:04 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_charts_for_users.php 200
ERROR - 2013-06-04 03:26:50 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_charts_for_users.php 200
ERROR - 2013-06-04 03:27:04 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_charts_for_users.php 200
ERROR - 2013-06-04 03:27:08 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_charts_for_users.php 200
ERROR - 2013-06-04 16:52:10 --> 404 Page Not Found --> app/banking
ERROR - 2013-06-04 18:58:36 --> Severity: Notice  --> Undefined property: stdClass::$submitted /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/manage.php 69
ERROR - 2013-06-04 18:58:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/Shwcase_Artist/system/helpers/url_helper.php 540
ERROR - 2013-06-04 18:59:05 --> Query error: Unknown column 'App_ID' in 'where clause'
ERROR - 2013-06-04 19:06:49 --> Severity: Notice  --> Undefined variable: selected_font /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 196
ERROR - 2013-06-04 19:07:40 --> Severity: Notice  --> Undefined variable: selected_font /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 196
ERROR - 2013-06-04 19:09:07 --> Severity: Notice  --> Undefined variable: selected_font /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 198
ERROR - 2013-06-04 19:10:02 --> Severity: Notice  --> Undefined variable: selected_font /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 199
ERROR - 2013-06-04 19:10:31 --> Severity: Notice  --> Undefined variable: selected_font /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 200
ERROR - 2013-06-04 19:10:46 --> Severity: Notice  --> Undefined variable: selected_font /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 200
ERROR - 2013-06-04 19:11:10 --> Severity: Notice  --> Undefined variable: selected_font /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 200
ERROR - 2013-06-04 19:11:52 --> Severity: Notice  --> Undefined variable: selected_font /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 200
ERROR - 2013-06-04 19:16:49 --> Severity: Notice  --> Undefined variable: selected_font /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 200
ERROR - 2013-06-04 19:26:09 --> Severity: Notice  --> Undefined variable: selected_font /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 200
ERROR - 2013-06-04 19:26:14 --> Severity: Notice  --> Undefined variable: selected_font /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 200
ERROR - 2013-06-04 19:26:14 --> Severity: Notice  --> Undefined variable: selected_font /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 200
ERROR - 2013-06-04 19:26:34 --> Severity: Notice  --> Undefined variable: selected_font /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 200
ERROR - 2013-06-04 19:32:06 --> Severity: Notice  --> Undefined variable: selected_font /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 240
ERROR - 2013-06-04 19:33:04 --> Severity: Notice  --> Undefined variable: selected_font /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 240
ERROR - 2013-06-04 19:34:12 --> 404 Page Not Found --> process/index
ERROR - 2013-06-04 19:34:14 --> 404 Page Not Found --> process/index
ERROR - 2013-06-04 19:36:01 --> 404 Page Not Found --> process/index
ERROR - 2013-06-04 19:36:06 --> 404 Page Not Found --> apps
ERROR - 2013-06-04 19:37:35 --> 404 Page Not Found --> process/manage_app
ERROR - 2013-06-04 19:38:56 --> 404 Page Not Found --> app/js
ERROR - 2013-06-04 19:39:15 --> 404 Page Not Found --> process/manage_app
ERROR - 2013-06-04 19:39:20 --> Severity: Notice  --> Undefined variable: selected_font /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 240
ERROR - 2013-06-04 19:39:41 --> 404 Page Not Found --> process/manage_app
ERROR - 2013-06-04 19:39:42 --> 404 Page Not Found --> process/manage_app
ERROR - 2013-06-04 19:40:15 --> 404 Page Not Found --> process/index
ERROR - 2013-06-04 19:40:19 --> 404 Page Not Found --> process/manage_app
ERROR - 2013-06-04 19:40:48 --> 404 Page Not Found --> process/manage_app
ERROR - 2013-06-04 19:40:49 --> 404 Page Not Found --> process/manage_app
ERROR - 2013-06-04 19:41:19 --> 404 Page Not Found --> process/manage_app
ERROR - 2013-06-04 19:41:21 --> 404 Page Not Found --> process/manage_app
ERROR - 2013-06-04 19:41:23 --> 404 Page Not Found --> process/index
ERROR - 2013-06-04 19:43:34 --> 404 Page Not Found --> process/index
ERROR - 2013-06-04 19:43:36 --> 404 Page Not Found --> process/index
ERROR - 2013-06-04 19:43:39 --> 404 Page Not Found --> process/create
ERROR - 2013-06-04 19:43:50 --> 404 Page Not Found --> process/manage_app
ERROR - 2013-06-04 19:43:52 --> 404 Page Not Found --> process/manage_app
ERROR - 2013-06-04 19:44:38 --> 404 Page Not Found --> process/manage_app
ERROR - 2013-06-04 19:44:41 --> 404 Page Not Found --> process/manage_app
ERROR - 2013-06-04 19:45:36 --> 404 Page Not Found --> process/manage_app
ERROR - 2013-06-04 19:45:49 --> Severity: Notice  --> Undefined variable: selected_font /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 240
ERROR - 2013-06-04 19:45:49 --> 404 Page Not Found --> process/js
ERROR - 2013-06-04 19:46:51 --> Severity: Warning  --> Missing argument 1 for entertainment::simple_record_main() /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/entertainment.php 394
ERROR - 2013-06-04 19:46:59 --> Severity: Warning  --> Missing argument 1 for entertainment::themechange() /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/entertainment.php 233
ERROR - 2013-06-04 19:46:59 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_insert_update_music_app.php 405
ERROR - 2013-06-04 19:46:59 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_insert_update_music_app.php 406
ERROR - 2013-06-04 19:46:59 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_insert_update_music_app.php 407
ERROR - 2013-06-04 19:46:59 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_insert_update_music_app.php 408
ERROR - 2013-06-04 19:46:59 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_insert_update_music_app.php 409
ERROR - 2013-06-04 19:46:59 --> Query error: Column 'r' cannot be null
ERROR - 2013-06-04 19:46:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Common.php 442
ERROR - 2013-06-04 19:47:36 --> Severity: Notice  --> Undefined variable: userArray /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/process.php 53
ERROR - 2013-06-04 19:47:36 --> Severity: Notice  --> Undefined variable: selected_font /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 240
ERROR - 2013-06-04 19:47:36 --> 404 Page Not Found --> process/js
ERROR - 2013-06-04 19:49:13 --> Severity: Notice  --> Undefined variable: pagename /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/process.php 41
ERROR - 2013-06-04 19:49:13 --> 404 Page Not Found --> process/js
ERROR - 2013-06-04 19:49:30 --> Severity: Notice  --> Undefined variable: pagename /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/process.php 41
ERROR - 2013-06-04 19:49:30 --> 404 Page Not Found --> process/js
ERROR - 2013-06-04 19:49:47 --> 404 Page Not Found --> process/js
ERROR - 2013-06-04 19:52:40 --> 404 Page Not Found --> process/js
ERROR - 2013-06-04 19:54:02 --> 404 Page Not Found --> process/js
ERROR - 2013-06-04 19:54:25 --> 404 Page Not Found --> process/js
ERROR - 2013-06-04 20:45:52 --> 404 Page Not Found --> process/js
ERROR - 2013-06-04 20:48:29 --> 404 Page Not Found --> process/js
ERROR - 2013-06-04 20:51:04 --> 404 Page Not Found --> process/js
ERROR - 2013-06-04 21:02:49 --> 404 Page Not Found --> process/manage_app
ERROR - 2013-06-04 21:02:53 --> 404 Page Not Found --> process/js
ERROR - 2013-06-04 21:04:58 --> 404 Page Not Found --> process/js
ERROR - 2013-06-04 21:07:53 --> 404 Page Not Found --> process/js
ERROR - 2013-06-04 21:08:20 --> 404 Page Not Found --> process/js
ERROR - 2013-06-04 21:11:10 --> 404 Page Not Found --> process/manage_app
ERROR - 2013-06-04 21:35:05 --> 404 Page Not Found --> process/manage_app
ERROR - 2013-06-04 21:35:23 --> 404 Page Not Found --> process/js
ERROR - 2013-06-04 21:46:30 --> Severity: Notice  --> Undefined variable: genre /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 1438
ERROR - 2013-06-04 21:46:38 --> Severity: Notice  --> Undefined variable: genre /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 1438
