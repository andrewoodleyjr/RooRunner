<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-06-05 00:49:56 --> Severity: Notice  --> Undefined index: description /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 296
ERROR - 2013-06-05 00:49:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/Shwcase_Artist/system/helpers/url_helper.php 540
ERROR - 2013-06-05 01:21:00 --> 404 Page Not Found --> entertainment2/simple_record_main
ERROR - 2013-06-05 01:34:04 --> 404 Page Not Found --> entertainment2/simple_record_main
ERROR - 2013-06-05 01:34:16 --> 404 Page Not Found --> entertainment2/simple_record_main
ERROR - 2013-06-05 01:36:48 --> Severity: Notice  --> Undefined offset: 0 /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_musicapps.php 120
ERROR - 2013-06-05 01:36:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Common.php 442
ERROR - 2013-06-05 01:38:00 --> Severity: Notice  --> Undefined offset: 0 /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_musicapps.php 120
ERROR - 2013-06-05 01:38:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Common.php 442
ERROR - 2013-06-05 01:38:03 --> Severity: Notice  --> Undefined offset: 0 /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_musicapps.php 120
ERROR - 2013-06-05 01:38:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Common.php 442
ERROR - 2013-06-05 01:38:13 --> Severity: Notice  --> Undefined offset: 0 /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_musicapps.php 120
ERROR - 2013-06-05 01:38:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Common.php 442
ERROR - 2013-06-05 01:38:26 --> 404 Page Not Found --> entertainment2/simple_record_main
ERROR - 2013-06-05 02:01:20 --> 404 Page Not Found --> entertainment2/simple_record_main
ERROR - 2013-06-05 02:02:23 --> 404 Page Not Found --> entertainment2/simple_record_main
ERROR - 2013-06-05 02:03:16 --> 404 Page Not Found --> entertainment2/simple_record_main
ERROR - 2013-06-05 02:03:54 --> 404 Page Not Found --> entertainment2/simple_record_main
ERROR - 2013-06-05 02:04:46 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_musicapps.php 112
ERROR - 2013-06-05 02:04:46 --> Query error: Unknown column 'genre' in 'field list'
ERROR - 2013-06-05 02:04:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Common.php 442
ERROR - 2013-06-05 02:25:13 --> Query error: Unknown column 'music_type' in 'field list'
ERROR - 2013-06-05 02:28:48 --> Query error: Unknown column 'music_type=' in 'field list'
ERROR - 2013-06-05 02:30:19 --> Query error: Unknown column 'music_type=' in 'field list'
ERROR - 2013-06-05 02:34:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'asd = '' WHERE `id` = 10' at line 1
ERROR - 2013-06-05 02:36:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'asd = '' WHERE `id` = 10' at line 1
ERROR - 2013-06-05 02:37:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'World = '' WHERE `id` = 10' at line 1
ERROR - 2013-06-05 02:41:52 --> Query error: Unknown column 'App_ID' in 'field list'
ERROR - 2013-06-05 02:43:10 --> Query error: Unknown column 'asasd' in 'field list'
ERROR - 2013-06-05 02:43:12 --> Query error: Unknown column 'asasd' in 'field list'
ERROR - 2013-06-05 02:46:00 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_musicapps.php 121
ERROR - 2013-06-05 02:46:24 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_musicapps.php 122
ERROR - 2013-06-05 02:47:08 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_musicapps.php 122
ERROR - 2013-06-05 02:48:19 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_musicapps.php 122
ERROR - 2013-06-05 02:49:06 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_musicapps.php 122
ERROR - 2013-06-05 02:49:06 --> Severity: Notice  --> Undefined offset: 0 /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_musicapps.php 123
ERROR - 2013-06-05 02:49:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Common.php 442
ERROR - 2013-06-05 02:49:15 --> Severity: Warning  --> Creating default object from empty value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_musicapps.php 122
ERROR - 2013-06-05 02:51:56 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_musicapps.php 122
ERROR - 2013-06-05 02:51:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Common.php 442
ERROR - 2013-06-05 02:53:47 --> Severity: Notice  --> Undefined offset: 0 /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_musicapps.php 123
ERROR - 2013-06-05 02:53:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Common.php 442
ERROR - 2013-06-05 03:10:49 --> Severity: Notice  --> Undefined property: stdClass::$id /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_page_entertainment.php 350
ERROR - 2013-06-05 03:10:49 --> Severity: Notice  --> Undefined variable: selected_font /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 239
ERROR - 2013-06-05 03:12:04 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 1474
ERROR - 2013-06-05 03:12:08 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 1474
ERROR - 2013-06-05 03:12:20 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 1474
ERROR - 2013-06-05 03:13:03 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/Shwcase_Artist/application/views/process/create.php 1474
ERROR - 2013-06-05 03:25:54 --> Severity: Notice  --> Undefined property: stdClass::$name /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_musicapps.php 164
ERROR - 2013-06-05 03:25:54 --> Severity: Notice  --> Undefined property: stdClass::$value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_insert_update_music_app.php 282
ERROR - 2013-06-05 03:25:54 --> Severity: Notice  --> Undefined property: stdClass::$name /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_insert_update_music_app.php 283
ERROR - 2013-06-05 03:25:54 --> Query error: Column 'value' cannot be null
ERROR - 2013-06-05 03:25:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Common.php 442
ERROR - 2013-06-05 03:26:15 --> Severity: Notice  --> Undefined property: stdClass::$name /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_musicapps.php 164
ERROR - 2013-06-05 03:26:15 --> Severity: Notice  --> Undefined property: stdClass::$value /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_insert_update_music_app.php 282
ERROR - 2013-06-05 03:26:15 --> Severity: Notice  --> Undefined property: stdClass::$name /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_insert_update_music_app.php 283
ERROR - 2013-06-05 03:26:15 --> Query error: Column 'value' cannot be null
ERROR - 2013-06-05 03:26:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Common.php 442
ERROR - 2013-06-05 04:19:44 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 04:19:45 --> 404 Page Not Found --> process/events
ERROR - 2013-06-05 04:19:49 --> 404 Page Not Found --> process/events
ERROR - 2013-06-05 04:20:08 --> 404 Page Not Found --> process/events
ERROR - 2013-06-05 04:22:25 --> 404 Page Not Found --> process/event
ERROR - 2013-06-05 04:31:08 --> Severity: Warning  --> Missing argument 1 for process::index() /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/process.php 31
ERROR - 2013-06-05 04:31:08 --> Severity: Notice  --> Undefined variable: pagename /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/process.php 40
ERROR - 2013-06-05 04:31:11 --> Severity: Warning  --> Missing argument 1 for process::index() /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/process.php 31
ERROR - 2013-06-05 04:31:11 --> Severity: Notice  --> Undefined variable: pagename /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/process.php 40
ERROR - 2013-06-05 04:31:11 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 04:31:13 --> 404 Page Not Found --> process/home
ERROR - 2013-06-05 04:31:29 --> Severity: Warning  --> Missing argument 1 for process::index() /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/process.php 31
ERROR - 2013-06-05 04:31:29 --> Severity: Notice  --> Undefined variable: pagename /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/process.php 40
ERROR - 2013-06-05 04:31:29 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 04:34:38 --> Severity: Warning  --> Missing argument 1 for process::index() /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/process.php 31
ERROR - 2013-06-05 04:34:38 --> Severity: Notice  --> Undefined variable: pagename /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/process.php 40
ERROR - 2013-06-05 04:34:38 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 04:40:48 --> 404 Page Not Found --> process/start
ERROR - 2013-06-05 04:41:11 --> Severity: Warning  --> Missing argument 1 for process::start() /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/process.php 31
ERROR - 2013-06-05 04:41:11 --> Severity: Notice  --> Undefined variable: pagename /Applications/MAMP/htdocs/Shwcase_Artist/application/controllers/process.php 40
ERROR - 2013-06-05 04:41:11 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 04:41:25 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 04:42:01 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 04:42:51 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 04:42:51 --> 404 Page Not Found --> process/scripts
ERROR - 2013-06-05 04:42:51 --> 404 Page Not Found --> process/scripts
ERROR - 2013-06-05 04:42:51 --> 404 Page Not Found --> process/scripts
ERROR - 2013-06-05 04:42:51 --> 404 Page Not Found --> process/scripts
ERROR - 2013-06-05 04:42:51 --> 404 Page Not Found --> process/scripts
ERROR - 2013-06-05 04:43:11 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 04:43:35 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 04:47:01 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 04:47:08 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 04:48:37 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 04:49:00 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 04:49:24 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 05:14:35 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 05:15:31 --> 404 Page Not Found --> process/entertainment2
ERROR - 2013-06-05 05:16:52 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 05:18:00 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 05:18:31 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 05:18:39 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 05:19:14 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 05:19:19 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 05:20:58 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 05:27:46 --> The upload path does not appear to be valid.
ERROR - 2013-06-05 05:31:48 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 05:31:50 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 05:33:38 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 05:37:52 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 05:38:11 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 05:48:39 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 05:50:27 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 19:31:06 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 20:06:51 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 20:13:04 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 20:24:12 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 20:24:27 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 20:25:46 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 20:25:54 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 20:27:25 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 20:27:28 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 20:27:29 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 20:42:02 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 20:46:42 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 20:47:24 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 20:48:05 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 20:51:45 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 20:53:04 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 21:51:35 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 21:52:17 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:09:58 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:10:27 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:10:51 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:11:20 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:15:38 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:15:57 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:17:15 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:20:32 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:20:49 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:21:13 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:23:00 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:23:58 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:24:31 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:35:22 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:35:40 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:35:45 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:40:12 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:41:08 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:41:45 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:44:43 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:45:07 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:47:29 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:47:44 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:51:12 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:51:40 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 22:56:26 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 23:17:33 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 23:21:14 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 23:24:48 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 23:28:34 --> 404 Page Not Found --> process/js
ERROR - 2013-06-05 23:28:44 --> Severity: Notice  --> Undefined index: description /Applications/MAMP/htdocs/Shwcase_Artist/application/models/model_apps.php 296
ERROR - 2013-06-05 23:28:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/Shwcase_Artist/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/Shwcase_Artist/system/helpers/url_helper.php 540
ERROR - 2013-06-05 23:34:56 --> 404 Page Not Found --> process/js
