<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-23 00:27:53 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-23 05:20:52 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-23 09:14:24 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-23 09:57:01 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-23 13:05:48 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-23 18:45:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-23 18:45:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-23 18:45:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-23 19:43:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-23 19:43:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-23 21:51:15 --> 404 Page Not Found --> register
ERROR - 2013-05-23 21:51:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-23 21:51:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-23 21:52:24 --> 404 Page Not Found --> favicon.ico
