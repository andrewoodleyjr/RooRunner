<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-04-28 02:12:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-28 02:19:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home2/adthrif1/public_html/artists/application/models/model_musicapps.php 105
ERROR - 2013-04-28 02:20:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home2/adthrif1/public_html/artists/application/models/model_musicapps.php 105
ERROR - 2013-04-28 02:21:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home2/adthrif1/public_html/artists/application/models/model_musicapps.php 105
ERROR - 2013-04-28 02:22:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home2/adthrif1/public_html/artists/application/models/model_musicapps.php 105
ERROR - 2013-04-28 02:22:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home2/adthrif1/public_html/artists/application/models/model_musicapps.php 105
ERROR - 2013-04-28 02:23:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home2/adthrif1/public_html/artists/application/models/model_musicapps.php 105
ERROR - 2013-04-28 02:25:36 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-28 02:26:33 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-04-28 02:27:16 --> Severity: Warning  --> unlink(/home2/adthrif1/public_html/connect_showcase/files/apps/): Is a directory /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 231
ERROR - 2013-04-28 02:28:10 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-04-28 02:28:26 --> Severity: Warning  --> unlink(/home2/adthrif1/public_html/connect_showcase/files/apps/): Is a directory /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 231
ERROR - 2013-04-28 02:30:19 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-04-28 02:39:42 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-04-28 02:40:38 --> Severity: Warning  --> unlink(/home2/adthrif1/public_html/connect_showcase/files/apps/): Is a directory /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 231
ERROR - 2013-04-28 02:40:46 --> Severity: Warning  --> unlink(/home2/adthrif1/public_html/connect_showcase/files/apps/): Is a directory /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 231
ERROR - 2013-04-28 02:47:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-28 02:48:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-28 02:49:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-28 02:53:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-28 03:06:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-28 03:32:25 --> Severity: Warning  --> unlink(/home2/adthrif1/public_html/connect_showcase/files/apps/): Is a directory /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 231
ERROR - 2013-04-28 12:45:49 --> 404 Page Not Found --> robots.txt
