<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-04-14 10:55:21 --> 404 Page Not Found --> images
ERROR - 2013-04-14 10:55:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-14 12:01:30 --> 404 Page Not Found --> robots.txt
