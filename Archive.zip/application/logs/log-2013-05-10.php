<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-10 08:43:36 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-10 10:14:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-10 10:16:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-10 10:16:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-10 14:22:58 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-10 17:32:26 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-10 18:10:06 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-10 23:59:42 --> 404 Page Not Found --> favicon.ico
