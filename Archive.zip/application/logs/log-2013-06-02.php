<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-06-02 22:17:17 --> 404 Page Not Found --> view.php
ERROR - 2013-06-02 22:23:07 --> 404 Page Not Found --> view.php
ERROR - 2013-06-02 22:23:19 --> 404 Page Not Found --> view.php
ERROR - 2013-06-02 22:24:59 --> 404 Page Not Found --> view.php
ERROR - 2013-06-02 22:25:43 --> 404 Page Not Found --> view.php
ERROR - 2013-06-02 22:27:03 --> 404 Page Not Found --> view.php
