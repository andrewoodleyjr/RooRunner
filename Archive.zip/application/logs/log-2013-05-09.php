<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-09 00:26:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-09 00:26:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-09 05:26:19 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-09 08:06:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-09 09:20:47 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-09 10:41:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-09 10:56:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-09 10:56:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-09 13:55:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-09 13:57:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-09 13:58:25 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-09 14:44:58 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-09 16:04:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-09 16:05:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-09 16:15:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home2/adthrif1/public_html/artists/application/models/model_musicapps.php 105
ERROR - 2013-05-09 16:15:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home2/adthrif1/public_html/artists/application/models/model_musicapps.php 105
ERROR - 2013-05-09 17:40:26 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-09 19:46:39 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-09 21:10:39 --> 404 Page Not Found --> robots.txt
