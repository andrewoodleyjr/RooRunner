<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-17 05:23:57 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-17 09:07:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-17 09:21:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-17 09:25:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-17 09:27:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-17 09:51:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-17 11:49:46 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-17 11:56:44 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-17 12:15:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-17 12:22:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-17 12:27:00 --> Severity: Notice  --> Undefined property: stdClass::$id /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 254
ERROR - 2013-05-17 12:27:00 --> Severity: Notice  --> Undefined property: stdClass::$id /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 256
ERROR - 2013-05-17 12:27:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2013-05-17 12:29:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-17 12:37:07 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-17 13:23:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-17 13:24:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-17 13:28:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-17 13:29:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-17 13:29:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-17 13:34:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-17 14:46:23 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-17 16:05:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-17 17:24:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-17 17:33:02 --> 404 Page Not Found --> favicon.ico
