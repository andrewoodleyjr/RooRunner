<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-11 02:50:04 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-11 03:31:10 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-11 09:04:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-11 09:20:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-11 09:26:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-11 09:31:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-11 09:34:15 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-05-11 09:35:30 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-05-11 09:39:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-11 09:45:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-11 12:11:10 --> 404 Page Not Found --> robots.txt
