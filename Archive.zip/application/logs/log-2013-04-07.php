<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-04-07 14:28:38 --> 404 Page Not Found --> robots.txt
