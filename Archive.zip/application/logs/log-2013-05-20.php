<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-20 02:14:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:17:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:17:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:18:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:18:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:22:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:22:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:27:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:27:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:28:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:29:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:29:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:29:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:36:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:37:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:37:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:40:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:40:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:40:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:42:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:42:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:42:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:42:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:42:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:52:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 02:58:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 03:00:40 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/models/model_apps.php 955
ERROR - 2013-05-20 03:00:41 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/models/model_apps.php 955
ERROR - 2013-05-20 03:06:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 03:11:09 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/models/model_apps.php 955
ERROR - 2013-05-20 03:11:59 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/models/model_apps.php 955
ERROR - 2013-05-20 03:18:05 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/models/model_apps.php 955
ERROR - 2013-05-20 03:47:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 03:51:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 03:51:15 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:51:15 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:51:15 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:51:15 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:51:15 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:51:15 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:51:15 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:51:15 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:51:15 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:51:15 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:51:15 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:51:15 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:51:15 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:51:15 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:51:15 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:51:15 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:51:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 03:52:37 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:52:37 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:52:37 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:52:37 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:52:37 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:52:37 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:52:37 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:52:37 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:52:59 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:52:59 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:52:59 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:52:59 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:52:59 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:52:59 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:52:59 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:52:59 --> Severity: Notice  --> Undefined index: 22343713 /home2/adthrif1/public_html/artists/application/models/model_page_entertainment.php 146
ERROR - 2013-05-20 03:53:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 03:53:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 03:53:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 03:54:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 03:54:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 03:54:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 03:54:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 03:54:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 04:01:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 04:10:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 04:10:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 04:10:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 04:11:35 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/models/model_apps.php 955
ERROR - 2013-05-20 04:18:09 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/models/model_apps.php 955
ERROR - 2013-05-20 04:20:19 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/models/model_apps.php 955
ERROR - 2013-05-20 04:29:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 04:30:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 04:44:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 05:45:28 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-20 09:07:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 09:07:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 12:08:40 --> 404 Page Not Found --> a
ERROR - 2013-05-20 14:14:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 14:14:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 14:18:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 20:49:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 20:49:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 20:49:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 20:49:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 20:49:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 20:49:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 20:54:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 22:45:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 22:45:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 22:45:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 22:45:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 22:45:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 22:47:20 --> APN: debugPayload response - status_code:7 => Invalid payload size
ERROR - 2013-05-20 23:04:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 23:04:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 23:07:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-20 23:11:06 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-20 23:28:30 --> 404 Page Not Found --> robots.txt
