<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-05-06 10:32:19 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-06 11:33:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 11:33:37 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-06 11:33:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 11:33:37 --> 404 Page Not Found --> js
ERROR - 2013-05-06 11:33:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 11:36:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 11:39:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 11:44:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home2/adthrif1/public_html/artists/application/models/model_musicapps.php 105
ERROR - 2013-05-06 11:45:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home2/adthrif1/public_html/artists/application/models/model_musicapps.php 105
ERROR - 2013-05-06 11:45:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home2/adthrif1/public_html/artists/application/models/model_musicapps.php 105
ERROR - 2013-05-06 11:46:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home2/adthrif1/public_html/artists/application/models/model_musicapps.php 105
ERROR - 2013-05-06 11:46:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home2/adthrif1/public_html/artists/application/models/model_musicapps.php 105
ERROR - 2013-05-06 11:46:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home2/adthrif1/public_html/artists/application/models/model_musicapps.php 105
ERROR - 2013-05-06 12:03:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 13:25:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 13:35:50 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-06 13:35:50 --> 404 Page Not Found --> js
ERROR - 2013-05-06 14:01:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 14:01:32 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-06 14:01:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 14:01:32 --> 404 Page Not Found --> js
ERROR - 2013-05-06 14:02:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 14:07:45 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-06 14:13:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 14:24:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 14:31:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 14:34:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 14:38:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 16:47:36 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-06 16:54:07 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 16:54:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 16:56:23 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-06 16:56:24 --> 404 Page Not Found --> js
ERROR - 2013-05-06 17:17:16 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-06 18:36:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 18:52:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 18:54:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 18:57:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 19:08:35 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 19:08:36 --> Severity: Notice  --> Undefined variable: submitted /home2/adthrif1/public_html/artists/application/controllers/manage.php 74
ERROR - 2013-05-06 19:08:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 19:08:36 --> Severity: Notice  --> Undefined variable: selected_font /home2/adthrif1/public_html/artists/application/views/process/create.php 196
ERROR - 2013-05-06 19:08:37 --> 404 Page Not Found --> js
ERROR - 2013-05-06 19:08:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 19:08:47 --> Severity: Warning  --> Missing argument 1 for process::skip_process() /home2/adthrif1/public_html/artists/application/controllers/process.php 195
ERROR - 2013-05-06 19:08:47 --> Severity: Notice  --> Undefined variable: id /home2/adthrif1/public_html/artists/application/controllers/process.php 199
ERROR - 2013-05-06 19:08:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2013-05-06 19:08:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 19:11:37 --> 404 Page Not Found --> robots.txt
ERROR - 2013-05-06 19:40:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-05-06 22:27:01 --> 404 Page Not Found --> robots.txt
