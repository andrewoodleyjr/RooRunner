<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-04-10 14:19:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-10 14:19:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-10 16:05:41 --> 404 Page Not Found --> robots.txt
