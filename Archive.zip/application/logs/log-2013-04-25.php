<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-04-25 00:07:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-25 00:07:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-25 00:33:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-25 00:38:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-25 00:52:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-25 00:56:19 --> 404 Page Not Found --> files
ERROR - 2013-04-25 00:56:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-25 00:56:24 --> 404 Page Not Found --> files
ERROR - 2013-04-25 00:56:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-25 12:40:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-25 12:41:19 --> The file you are attempting to upload is larger than the permitted size.
ERROR - 2013-04-25 13:55:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-25 14:07:11 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-25 14:24:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-25 14:24:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-25 14:24:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-25 21:11:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-25 21:11:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-25 23:20:56 --> 404 Page Not Found --> robots.txt
