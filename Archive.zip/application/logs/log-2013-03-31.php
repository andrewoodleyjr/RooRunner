<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-03-31 07:28:12 --> 404 Page Not Found --> robots.txt
ERROR - 2013-03-31 08:44:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 08:44:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 08:44:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 08:44:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 08:44:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 08:44:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 08:44:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 08:45:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 08:45:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 08:45:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 08:45:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 08:45:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 08:45:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 08:46:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 08:46:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 08:46:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 08:58:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 08:58:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 09:06:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 09:32:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 09:39:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 09:40:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 09:47:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 09:48:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 09:53:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 09:53:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 09:53:42 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 09:59:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 09:59:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 09:59:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 10:00:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 10:00:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 10:00:04 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 11:46:07 --> 404 Page Not Found --> robots.txt
ERROR - 2013-03-31 12:00:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:00:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:00:46 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:00:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:00:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:03:30 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:04:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:08:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:09:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:15:45 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:15:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:16:26 --> Severity: Notice  --> A non well formed numeric value encountered /home2/adthrif1/public_html/artists/application/models/model_apps.php 403
ERROR - 2013-03-31 12:18:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:18:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:19:23 --> Severity: Notice  --> A non well formed numeric value encountered /home2/adthrif1/public_html/artists/application/models/model_apps.php 409
ERROR - 2013-03-31 12:19:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:20:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:22:28 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:23:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:41:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:43:03 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:43:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:43:48 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:44:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:44:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:47:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:47:32 --> Severity: Notice  --> Undefined offset:  0 /home2/adthrif1/public_html/artists/application/models/model_payments.php 142
ERROR - 2013-03-31 12:47:32 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/models/model_payments.php 142
ERROR - 2013-03-31 12:47:32 --> Severity: Notice  --> Undefined offset:  0 /home2/adthrif1/public_html/artists/application/models/model_payments.php 142
ERROR - 2013-03-31 12:47:32 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/models/model_payments.php 142
ERROR - 2013-03-31 12:47:32 --> Severity: Notice  --> Undefined offset:  0 /home2/adthrif1/public_html/artists/application/models/model_payments.php 143
ERROR - 2013-03-31 12:47:32 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/models/model_payments.php 143
ERROR - 2013-03-31 12:47:32 --> Severity: Notice  --> Undefined offset:  0 /home2/adthrif1/public_html/artists/application/models/model_payments.php 143
ERROR - 2013-03-31 12:47:32 --> Severity: Notice  --> Trying to get property of non-object /home2/adthrif1/public_html/artists/application/models/model_payments.php 143
ERROR - 2013-03-31 12:47:33 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:47:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:49:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:50:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:53:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:53:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:56:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 12:56:40 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 13:05:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 13:15:53 --> Severity: Warning  --> DateTime::add() expects parameter 1 to be DateInterval, string given /home2/adthrif1/public_html/artists/application/models/model_apps.php 403
ERROR - 2013-03-31 13:16:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 13:17:05 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 13:17:32 --> Severity: Warning  --> DateTime::add() expects parameter 1 to be DateInterval, string given /home2/adthrif1/public_html/artists/application/models/model_apps.php 401
ERROR - 2013-03-31 13:19:10 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 13:19:35 --> Severity: Warning  --> DateTime::add() expects parameter 1 to be DateInterval, string given /home2/adthrif1/public_html/artists/application/models/model_apps.php 404
ERROR - 2013-03-31 13:21:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 13:21:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 13:21:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 13:22:02 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 13:22:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 13:22:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 13:22:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 13:23:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 13:28:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 13:28:13 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 13:42:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 13:42:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 14:04:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 14:05:06 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 14:05:08 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 14:05:14 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 14:05:23 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 14:05:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 14:05:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 14:06:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 14:06:50 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 14:06:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 14:24:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 14:24:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 14:24:54 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 16:16:14 --> Severity: Warning  --> Missing argument 1 for cron::runCron() /home2/adthrif1/public_html/artists/application/controllers/cron.php 15
ERROR - 2013-03-31 16:16:14 --> Severity: Notice  --> Undefined variable: pass /home2/adthrif1/public_html/artists/application/controllers/cron.php 16
ERROR - 2013-03-31 16:16:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 16:17:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 16:17:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 16:18:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 16:32:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-03-31 19:31:32 --> 404 Page Not Found --> robots.txt
ERROR - 2013-03-31 23:48:01 --> 404 Page Not Found --> favicon.ico
