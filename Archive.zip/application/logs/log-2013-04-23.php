<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-04-23 00:27:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 00:27:52 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
ERROR - 2013-04-23 01:22:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 01:32:52 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 01:43:51 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 01:43:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 02:22:16 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 11:56:55 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-23 17:14:09 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 17:19:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 17:26:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 17:31:17 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-04-23 17:35:47 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 17:41:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 17:47:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 17:51:39 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 17:54:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 18:42:51 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-23 19:00:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 19:01:13 --> 404 Page Not Found --> files
ERROR - 2013-04-23 19:03:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 20:16:22 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 20:16:31 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 20:21:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 20:29:15 --> The file you are attempting to upload is larger than the permitted size.
ERROR - 2013-04-23 20:29:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 20:30:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 20:31:01 --> The file you are attempting to upload is larger than the permitted size.
ERROR - 2013-04-23 20:31:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 20:35:01 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 20:42:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 21:01:24 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-23 21:03:15 --> 404 Page Not Found --> favicon.ico
