<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-04-09 11:19:07 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-09 11:46:12 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-09 19:03:20 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-09 19:31:13 --> Severity: Warning  --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094416:SSL routines:SSL3_READ_BYTES:sslv3 alert certificate unknown /home2/adthrif1/public_html/artists/application/libraries/apn.php 81
ERROR - 2013-04-09 19:31:13 --> Severity: Warning  --> stream_socket_client(): Failed to enable crypto /home2/adthrif1/public_html/artists/application/libraries/apn.php 81
ERROR - 2013-04-09 19:31:13 --> Severity: Warning  --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /home2/adthrif1/public_html/artists/application/libraries/apn.php 81
ERROR - 2013-04-09 19:33:26 --> Severity: Warning  --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094416:SSL routines:SSL3_READ_BYTES:sslv3 alert certificate unknown /home2/adthrif1/public_html/artists/application/libraries/apn.php 81
ERROR - 2013-04-09 19:33:26 --> Severity: Warning  --> stream_socket_client(): Failed to enable crypto /home2/adthrif1/public_html/artists/application/libraries/apn.php 81
ERROR - 2013-04-09 19:33:26 --> Severity: Warning  --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /home2/adthrif1/public_html/artists/application/libraries/apn.php 81
ERROR - 2013-04-09 19:33:49 --> Severity: Warning  --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094416:SSL routines:SSL3_READ_BYTES:sslv3 alert certificate unknown /home2/adthrif1/public_html/artists/application/libraries/apn.php 81
ERROR - 2013-04-09 19:33:49 --> Severity: Warning  --> stream_socket_client(): Failed to enable crypto /home2/adthrif1/public_html/artists/application/libraries/apn.php 81
ERROR - 2013-04-09 19:33:49 --> Severity: Warning  --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /home2/adthrif1/public_html/artists/application/libraries/apn.php 81
ERROR - 2013-04-09 19:33:55 --> Severity: Warning  --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094416:SSL routines:SSL3_READ_BYTES:sslv3 alert certificate unknown /home2/adthrif1/public_html/artists/application/libraries/apn.php 81
ERROR - 2013-04-09 19:33:55 --> Severity: Warning  --> stream_socket_client(): Failed to enable crypto /home2/adthrif1/public_html/artists/application/libraries/apn.php 81
ERROR - 2013-04-09 19:33:55 --> Severity: Warning  --> stream_socket_client(): unable to connect to ssl://gateway.sandbox.push.apple.com:2195 (Unknown error) /home2/adthrif1/public_html/artists/application/libraries/apn.php 81
ERROR - 2013-04-09 19:50:32 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-09 19:50:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-09 19:53:11 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-09 19:56:37 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-09 19:58:36 --> Severity: Warning  --> stream_socket_client(): SSL operation failed with code 1. OpenSSL Error messages:
error:14094416:SSL routines:SSL3_READ_BYTES:sslv3 alert certificate unknown /home2/adthrif1/public_html/artists/application/libraries/apn.php 81
ERROR - 2013-04-09 19:58:36 --> Severity: Warning  --> stream_socket_client(): Failed to enable crypto /home2/adthrif1/public_html/artists/application/libraries/apn.php 81
ERROR - 2013-04-09 19:58:36 --> Severity: Warning  --> stream_socket_client(): unable to connect to ssl://gateway.push.apple.com:2195 (Unknown error) /home2/adthrif1/public_html/artists/application/libraries/apn.php 81
ERROR - 2013-04-09 20:20:17 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-09 20:21:36 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-09 20:31:15 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-09 20:32:26 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-09 20:38:29 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-09 20:41:53 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-09 20:43:43 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-09 20:45:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-09 20:46:59 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-09 20:47:49 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-09 20:49:00 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-09 20:49:44 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-09 20:50:19 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-09 20:52:21 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-09 20:55:46 --> 404 Page Not Found --> favicon.ico
