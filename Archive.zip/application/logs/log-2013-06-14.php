<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-06-14 01:36:40 --> 404 Page Not Found --> manage/message_runners
ERROR - 2013-06-14 01:44:27 --> 404 Page Not Found --> manage/message_runners
