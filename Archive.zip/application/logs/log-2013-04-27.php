<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-04-27 01:18:52 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-27 05:09:18 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-27 14:15:18 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-27 14:16:41 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-27 14:16:57 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-27 14:17:34 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-27 14:17:58 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-27 14:33:37 --> 404 Page Not Found --> robots.txt
ERROR - 2013-04-27 14:41:27 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-27 15:15:56 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-27 15:16:14 --> Severity: Warning  --> unlink(/home2/adthrif1/public_html/connect_showcase/files/apps/): Is a directory /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 231
ERROR - 2013-04-27 15:16:59 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-04-27 15:18:18 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-04-27 15:20:18 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-04-27 15:21:24 --> Severity: Warning  --> unlink(/home2/adthrif1/public_html/connect_showcase/files/apps/): Is a directory /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 231
ERROR - 2013-04-27 15:21:31 --> Severity: Warning  --> unlink(/home2/adthrif1/public_html/connect_showcase/files/apps/): Is a directory /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 231
ERROR - 2013-04-27 15:21:35 --> Severity: Warning  --> unlink(/home2/adthrif1/public_html/connect_showcase/files/apps/): Is a directory /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 231
ERROR - 2013-04-27 15:31:22 --> The filetype you are attempting to upload is not allowed.
ERROR - 2013-04-27 15:31:45 --> Severity: Warning  --> unlink(/home2/adthrif1/public_html/connect_showcase/files/apps/): Is a directory /home2/adthrif1/public_html/artists/application/models/model_insert_update_music_app.php 231
ERROR - 2013-04-27 15:34:38 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-27 15:35:12 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-27 20:36:55 --> 404 Page Not Found --> favicon.ico
ERROR - 2013-04-27 20:36:55 --> 404 Page Not Found --> favicon.ico
