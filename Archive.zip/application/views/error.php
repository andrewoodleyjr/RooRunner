<div class="container">
    <div class="alert alert-danger offset3 span5" style="margin-top: 90px;">
        <?php if(isset($error)){echo $error; } ?>
    </div>
</div>