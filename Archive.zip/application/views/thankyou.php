<br />
<div class="container">
    <div class="alert alert-success form-signin" style="margin:0 auto; text-align:center; background-color:#d6e9c6; !important" >
        <h7 style="color:#51a351; !important; font-size: 17.5px; font-weight: bold; font-family: inherit;" ><?php if(isset($message)) echo $message; ?></h7>
        <br/>
        <a href="http://www.roorunner.com" class="btn btn-large btn-success">Login</a>
    </div>
</div>