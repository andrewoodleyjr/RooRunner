            <div id="push"></div><!-- required for sticky footer -->
        </div>
    </div><!-- /#wrapper -->
    <div id="footer">
        <div class="container">
            <p class="credit">Produced by <a href="http://shwcase.co/" rel="nofollow" target="_blank">Shwcase</a> | UI/UX by <a href="http://vaughn.io/" rel="nofollow" target="_blank">Vaughn D. Taylor</a></p>
        </div>
    </div>
    <script src="/js/jquery-1.10.1.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
    <script src="/js/script.js"></script>
    <?php if(isset($js)){echo $js;} ?>
    <script>
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

      ga('create', 'UA-41719311-1', 'roorunner.com');
      ga('send', 'pageview');

    </script>
</body>
</html>