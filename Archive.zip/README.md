RooRunner
=========

Bonnaroo Task Runner Website &amp; Mobile App

To do list

1. Server Code 
  - ~~An email/alert sends out to all runners when a post is submitted.~~
  - ~~Runners can opt out of recieving alerts for new tasks (add column in DB)~~
  - ~~Consistent menu selections~~
  - ~~Update the session variables when updating the profile section.~~ 
  - ~~MESSAGES MUST BE SET UP AND EMAIL AND SMS SHOULD BE ENABLED user can choose either or... maybe... or required.~~
  - ~~Users can choose to become a runner in the settings field (radio selection, DB column is called type 0 regular 1 runner).~~
  - ~~button for all jobs show at the top when user is a runner.~~
  - ~~email/txt is sent to user when a task has been accepted!~~
  - ~~Confirmation text or confirmation email when user signs up...~~
  - ~~message your runners (int. with twilio)~~
  - ~~runners message users and script to send to twilio~~
  - Completed task functionality - voting system submit and store on DB. (both runner and users) -- In Progress
  - Cancelled task functionality - voting system submit and store on DB. (both runner and users) -- In Progress
  - Look into the payment functionality.
  
  
2. Clean Code
  - Take out unneccessary code
  - Test for speed / scalability 
  - Reuse Code
  - Comment Time!

3. UI & UX
  - Website Implementation
  - Email Design Implementation
  - Proper Wording

4. Team Discussion 
  - Business Model 
  - Bidder Model for users to select a runner
  - marketing plan 
  - improvement of features 


                                      !!!LETS HAVE A GREAT TIME BUILDING ROORUNNER!!! 

